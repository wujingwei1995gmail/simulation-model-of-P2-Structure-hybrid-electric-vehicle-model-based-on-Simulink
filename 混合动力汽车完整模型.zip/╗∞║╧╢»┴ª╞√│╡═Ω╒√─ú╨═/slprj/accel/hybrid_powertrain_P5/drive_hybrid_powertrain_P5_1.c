#include "__cf_hybrid_powertrain_P5.h"
#include "drive_hybrid_powertrain_P5_1.h"
DriveLine * _drive_hybrid_powertrain_P5_1_drive_line ; DriveLine *
drive_hybrid_powertrain_P5_1_drive_line (
drive_hybrid_powertrain_P5_1_data_table * _table ) { DriveLine * _dline ;
_dline = & _table -> _dline ; _dline -> compilerData = _table ->
DriveCompilerData_table ; _dline -> compilerData -> numBlocks = 35 ; _dline
-> compilerData -> block = _table -> DriveBlock_table ; _dline ->
compilerData -> block [ 0 ] . numFlanges = 1 ; _dline -> compilerData ->
block [ 0 ] . numSolver = 1 ; _dline -> compilerData -> block [ 0 ] . name =
( char * ) _table -> UINT8_table ; strcpy ( _dline -> compilerData -> block [
0 ] . name , "hybrid_powertrain_P5/Transmission/Driveline\\\\nEnvironment" )
; _dline -> compilerData -> block [ 0 ] . visibleName = ( char * ) ( _table
-> UINT8_table + 56 ) ; strcpy ( _dline -> compilerData -> block [ 0 ] .
visibleName , "hybrid_powertrain_P5/Transmission/Driveline\\\\nEnvironment" )
; _dline -> compilerData -> block [ 0 ] . type = DRIVESOLVER ; _dline ->
compilerData -> block [ 0 ] . flange = _table -> INT32_table ; _dline ->
compilerData -> block [ 0 ] . solver = _table -> DriveSolver_table ; _dline
-> compilerData -> block [ 0 ] . solver [ 0 ] . implementModeIteration = TRUE
; _dline -> compilerData -> block [ 0 ] . solver [ 0 ] .
defaultClutchVelocityTolerance = 0.001 ; _dline -> compilerData -> block [ 0
] . solver [ 0 ] . defaultAutomaticVarStepClutchVelocityTolerance = TRUE ;
_dline -> compilerData -> block [ 1 ] . numFlanges = 2 ; _dline ->
compilerData -> block [ 1 ] . numClutch = 1 ; _dline -> compilerData -> block
[ 1 ] . name = ( char * ) ( _table -> UINT8_table + 112 ) ; strcpy ( _dline
-> compilerData -> block [ 1 ] . name ,
 "hybrid_powertrain_P5/Transmission/Gearbox ED/Controllable\\\\nFriction Clutch1/Fundamental\\\\nFriction Clutch"
) ; _dline -> compilerData -> block [ 1 ] . visibleName = ( char * ) ( _table
-> UINT8_table + 215 ) ; strcpy ( _dline -> compilerData -> block [ 1 ] .
visibleName ,
"hybrid_powertrain_P5/Transmission/Gearbox ED/Controllable\\\\nFriction Clutch1"
) ; _dline -> compilerData -> block [ 1 ] . type = DRIVECLUTCH ; _dline ->
compilerData -> block [ 1 ] . flange = _table -> INT32_table + 1 ; _dline ->
compilerData -> block [ 1 ] . flange [ 1 ] = 1 ; _dline -> compilerData ->
block [ 1 ] . clutch = _table -> DriveClutch_table ; _dline -> compilerData
-> block [ 1 ] . clutch [ 0 ] . mode = DRIVEUNLOCKED ; _dline -> compilerData
-> block [ 1 ] . clutch [ 0 ] . outputFlange = 1 ; _dline -> compilerData ->
block [ 1 ] . clutch [ 0 ] . modeFlag = ( char * ) ( _table -> UINT8_table +
290 ) ; strcpy ( _dline -> compilerData -> block [ 1 ] . clutch [ 0 ] .
modeFlag , "drive_1c093d6amode" ) ; _dline -> compilerData -> block [ 1 ] .
clutch [ 0 ] . velocityFlag = ( char * ) ( _table -> UINT8_table + 309 ) ;
strcpy ( _dline -> compilerData -> block [ 1 ] . clutch [ 0 ] . velocityFlag
, "drive_1c093d6avelocity" ) ; _dline -> compilerData -> block [ 1 ] . clutch
[ 0 ] . kineticFrictionTorqueFlag = ( char * ) ( _table -> UINT8_table + 332
) ; strcpy ( _dline -> compilerData -> block [ 1 ] . clutch [ 0 ] .
kineticFrictionTorqueFlag , "drive_1c093d6akinFricTor" ) ; _dline ->
compilerData -> block [ 1 ] . clutch [ 0 ] . posStaticFricPeakFlag = ( char *
) ( _table -> UINT8_table + 357 ) ; strcpy ( _dline -> compilerData -> block
[ 1 ] . clutch [ 0 ] . posStaticFricPeakFlag ,
"drive_1c093d6aposStaticFricPeak" ) ; _dline -> compilerData -> block [ 1 ] .
clutch [ 0 ] . negStaticFricPeakFlag = ( char * ) ( _table -> UINT8_table +
389 ) ; strcpy ( _dline -> compilerData -> block [ 1 ] . clutch [ 0 ] .
negStaticFricPeakFlag , "drive_1c093d6anegStaticFricPeak" ) ; _dline ->
compilerData -> block [ 1 ] . clutch [ 0 ] . outputMode = TRUE ; _dline ->
compilerData -> block [ 1 ] . clutch [ 0 ] . lockAtStart = TRUE ; _dline ->
compilerData -> block [ 1 ] . clutch [ 0 ] . velocityTolerance = 0.001 ;
_dline -> compilerData -> block [ 1 ] . clutch [ 0 ] .
automaticVarStepVelocityTolerance = TRUE ; _dline -> compilerData -> block [
1 ] . clutch [ 0 ] . useDefaultVelocityTolerance = TRUE ; _dline ->
compilerData -> block [ 2 ] . numFlanges = 2 ; _dline -> compilerData ->
block [ 2 ] . numParameters = 1 ; _dline -> compilerData -> block [ 2 ] .
parameter = _table -> DriveParameter_table ; _dline -> compilerData -> block
[ 2 ] . parameter [ 0 ] . type = DRIVERTP_SIMPLEGEARRATIO ; _dline ->
compilerData -> block [ 2 ] . parameter [ 0 ] . flag = ( char * ) ( _table ->
UINT8_table + 421 ) ; strcpy ( _dline -> compilerData -> block [ 2 ] .
parameter [ 0 ] . flag , "drive_afe7bedcGearRatio" ) ; _dline -> compilerData
-> block [ 2 ] . numSimpleGear = 1 ; _dline -> compilerData -> block [ 2 ] .
name = ( char * ) ( _table -> UINT8_table + 445 ) ; strcpy ( _dline ->
compilerData -> block [ 2 ] . name ,
"hybrid_powertrain_P5/Transmission/Gearbox ED/Simple Gear" ) ; _dline ->
compilerData -> block [ 2 ] . visibleName = ( char * ) ( _table ->
UINT8_table + 502 ) ; strcpy ( _dline -> compilerData -> block [ 2 ] .
visibleName , "hybrid_powertrain_P5/Transmission/Gearbox ED/Simple Gear" ) ;
_dline -> compilerData -> block [ 2 ] . type = DRIVESIMPLEGEAR ; _dline ->
compilerData -> block [ 2 ] . flange = _table -> INT32_table + 3 ; _dline ->
compilerData -> block [ 2 ] . flange [ 0 ] = 1 ; _dline -> compilerData ->
block [ 2 ] . flange [ 1 ] = 2 ; _dline -> compilerData -> block [ 2 ] .
simpleGear = _table -> DriveSimpleGear_table ; _dline -> compilerData ->
block [ 2 ] . simpleGear [ 0 ] . outputFlange = 1 ; _dline -> compilerData ->
block [ 2 ] . simpleGear [ 0 ] . ratio = 20.0 ; _dline -> compilerData ->
block [ 3 ] . numFlanges = 2 ; _dline -> compilerData -> block [ 3 ] .
numClutch = 1 ; _dline -> compilerData -> block [ 3 ] . name = ( char * ) (
_table -> UINT8_table + 559 ) ; strcpy ( _dline -> compilerData -> block [ 3
] . name ,
 "hybrid_powertrain_P5/Transmission/Drive\\\\nClutch1/Fundamental\\\\nFriction Clutch"
) ; _dline -> compilerData -> block [ 3 ] . visibleName = ( char * ) ( _table
-> UINT8_table + 635 ) ; strcpy ( _dline -> compilerData -> block [ 3 ] .
visibleName , "hybrid_powertrain_P5/Transmission/Drive\\\\nClutch1" ) ;
_dline -> compilerData -> block [ 3 ] . type = DRIVECLUTCH ; _dline ->
compilerData -> block [ 3 ] . flange = _table -> INT32_table + 5 ; _dline ->
compilerData -> block [ 3 ] . flange [ 0 ] = 2 ; _dline -> compilerData ->
block [ 3 ] . flange [ 1 ] = 3 ; _dline -> compilerData -> block [ 3 ] .
clutch = _table -> DriveClutch_table + 1 ; _dline -> compilerData -> block [
3 ] . clutch [ 0 ] . mode = DRIVEUNLOCKED ; _dline -> compilerData -> block [
3 ] . clutch [ 0 ] . inputFlange = 1 ; _dline -> compilerData -> block [ 3 ]
. clutch [ 0 ] . modeFlag = ( char * ) ( _table -> UINT8_table + 683 ) ;
strcpy ( _dline -> compilerData -> block [ 3 ] . clutch [ 0 ] . modeFlag ,
"drive_ea290ab2mode" ) ; _dline -> compilerData -> block [ 3 ] . clutch [ 0 ]
. velocityFlag = ( char * ) ( _table -> UINT8_table + 702 ) ; strcpy ( _dline
-> compilerData -> block [ 3 ] . clutch [ 0 ] . velocityFlag ,
"drive_ea290ab2velocity" ) ; _dline -> compilerData -> block [ 3 ] . clutch [
0 ] . kineticFrictionTorqueFlag = ( char * ) ( _table -> UINT8_table + 725 )
; strcpy ( _dline -> compilerData -> block [ 3 ] . clutch [ 0 ] .
kineticFrictionTorqueFlag , "drive_ea290ab2kinFricTor" ) ; _dline ->
compilerData -> block [ 3 ] . clutch [ 0 ] . posStaticFricPeakFlag = ( char *
) ( _table -> UINT8_table + 750 ) ; strcpy ( _dline -> compilerData -> block
[ 3 ] . clutch [ 0 ] . posStaticFricPeakFlag ,
"drive_ea290ab2posStaticFricPeak" ) ; _dline -> compilerData -> block [ 3 ] .
clutch [ 0 ] . negStaticFricPeakFlag = ( char * ) ( _table -> UINT8_table +
782 ) ; strcpy ( _dline -> compilerData -> block [ 3 ] . clutch [ 0 ] .
negStaticFricPeakFlag , "drive_ea290ab2negStaticFricPeak" ) ; _dline ->
compilerData -> block [ 3 ] . clutch [ 0 ] . outputMode = TRUE ; _dline ->
compilerData -> block [ 3 ] . clutch [ 0 ] . lockAtStart = TRUE ; _dline ->
compilerData -> block [ 3 ] . clutch [ 0 ] . velocityTolerance = 0.001 ;
_dline -> compilerData -> block [ 3 ] . clutch [ 0 ] .
automaticVarStepVelocityTolerance = TRUE ; _dline -> compilerData -> block [
3 ] . clutch [ 0 ] . useDefaultVelocityTolerance = TRUE ; _dline ->
compilerData -> block [ 4 ] . numFlanges = 1 ; _dline -> compilerData ->
block [ 4 ] . numWeld = 1 ; _dline -> compilerData -> block [ 4 ] . name = (
char * ) ( _table -> UINT8_table + 814 ) ; strcpy ( _dline -> compilerData ->
block [ 4 ] . name ,
"hybrid_powertrain_P5/Transmission/Housing2/Housing\\\\nInternal" ) ; _dline
-> compilerData -> block [ 4 ] . visibleName = ( char * ) ( _table ->
UINT8_table + 874 ) ; strcpy ( _dline -> compilerData -> block [ 4 ] .
visibleName , "hybrid_powertrain_P5/Transmission/Housing2" ) ; _dline ->
compilerData -> block [ 4 ] . type = DRIVEWELD ; _dline -> compilerData ->
block [ 4 ] . flange = _table -> INT32_table + 7 ; _dline -> compilerData ->
block [ 4 ] . flange [ 0 ] = 3 ; _dline -> compilerData -> block [ 4 ] . weld
= _table -> DriveWeld_table ; _dline -> compilerData -> block [ 4 ] . weld [
0 ] . isWeld = TRUE ; _dline -> compilerData -> block [ 5 ] . numFlanges = 2
; _dline -> compilerData -> block [ 5 ] . numParameters = 1 ; _dline ->
compilerData -> block [ 5 ] . parameter = _table -> DriveParameter_table + 1
; _dline -> compilerData -> block [ 5 ] . parameter [ 0 ] . type =
DRIVERTP_SIMPLEGEARRATIO ; _dline -> compilerData -> block [ 5 ] . parameter
[ 0 ] . flag = ( char * ) ( _table -> UINT8_table + 917 ) ; strcpy ( _dline
-> compilerData -> block [ 5 ] . parameter [ 0 ] . flag ,
"drive_31609934GearRatio" ) ; _dline -> compilerData -> block [ 5 ] .
numSimpleGear = 1 ; _dline -> compilerData -> block [ 5 ] . name = ( char * )
( _table -> UINT8_table + 941 ) ; strcpy ( _dline -> compilerData -> block [
5 ] . name , "hybrid_powertrain_P5/Transmission/Differential1/Simple Gear3" )
; _dline -> compilerData -> block [ 5 ] . visibleName = ( char * ) ( _table
-> UINT8_table + 1002 ) ; strcpy ( _dline -> compilerData -> block [ 5 ] .
visibleName , "hybrid_powertrain_P5/Transmission/Differential1" ) ; _dline ->
compilerData -> block [ 5 ] . type = DRIVESIMPLEGEAR ; _dline -> compilerData
-> block [ 5 ] . flange = _table -> INT32_table + 8 ; _dline -> compilerData
-> block [ 5 ] . flange [ 0 ] = 2 ; _dline -> compilerData -> block [ 5 ] .
flange [ 1 ] = 4 ; _dline -> compilerData -> block [ 5 ] . simpleGear =
_table -> DriveSimpleGear_table + 1 ; _dline -> compilerData -> block [ 5 ] .
simpleGear [ 0 ] . reversing = TRUE ; _dline -> compilerData -> block [ 5 ] .
simpleGear [ 0 ] . inputFlange = 1 ; _dline -> compilerData -> block [ 5 ] .
simpleGear [ 0 ] . ratio = 1.0 ; _dline -> compilerData -> block [ 6 ] .
numFlanges = 3 ; _dline -> compilerData -> block [ 6 ] . numParameters = 1 ;
_dline -> compilerData -> block [ 6 ] . parameter = _table ->
DriveParameter_table + 2 ; _dline -> compilerData -> block [ 6 ] . parameter
[ 0 ] . type = DRIVERTP_PLANETPLANETGEARRATIO ; _dline -> compilerData ->
block [ 6 ] . parameter [ 0 ] . flag = ( char * ) ( _table -> UINT8_table +
1050 ) ; strcpy ( _dline -> compilerData -> block [ 6 ] . parameter [ 0 ] .
flag , "drive_462b6e81PlanetPlanetRatio" ) ; _dline -> compilerData -> block
[ 6 ] . numPlanetPlanet = 1 ; _dline -> compilerData -> block [ 6 ] . name =
( char * ) ( _table -> UINT8_table + 1082 ) ; strcpy ( _dline -> compilerData
-> block [ 6 ] . name ,
"hybrid_powertrain_P5/Transmission/Differential1/Planet-Planet" ) ; _dline ->
compilerData -> block [ 6 ] . visibleName = ( char * ) ( _table ->
UINT8_table + 1144 ) ; strcpy ( _dline -> compilerData -> block [ 6 ] .
visibleName , "hybrid_powertrain_P5/Transmission/Differential1" ) ; _dline ->
compilerData -> block [ 6 ] . type = DRIVEPLANETPLANET ; _dline ->
compilerData -> block [ 6 ] . flange = _table -> INT32_table + 10 ; _dline ->
compilerData -> block [ 6 ] . flange [ 0 ] = 4 ; _dline -> compilerData ->
block [ 6 ] . flange [ 1 ] = 5 ; _dline -> compilerData -> block [ 6 ] .
flange [ 2 ] = 7 ; _dline -> compilerData -> block [ 6 ] . planetPlanet =
_table -> DrivePlanetPlanet_table ; _dline -> compilerData -> block [ 6 ] .
planetPlanet [ 0 ] . planetFlange = 2 ; _dline -> compilerData -> block [ 6 ]
. planetPlanet [ 0 ] . carrierFlange = 1 ; _dline -> compilerData -> block [
6 ] . planetPlanet [ 0 ] . ratio = 1.0 ; _dline -> compilerData -> block [ 7
] . numFlanges = 3 ; _dline -> compilerData -> block [ 7 ] . numParameters =
1 ; _dline -> compilerData -> block [ 7 ] . parameter = _table ->
DriveParameter_table + 3 ; _dline -> compilerData -> block [ 7 ] . parameter
[ 0 ] . type = DRIVERTP_PLANETPLANETGEARRATIO ; _dline -> compilerData ->
block [ 7 ] . parameter [ 0 ] . flag = ( char * ) ( _table -> UINT8_table +
1192 ) ; strcpy ( _dline -> compilerData -> block [ 7 ] . parameter [ 0 ] .
flag , "drive_d94ca344PlanetPlanetRatio" ) ; _dline -> compilerData -> block
[ 7 ] . numPlanetPlanet = 1 ; _dline -> compilerData -> block [ 7 ] . name =
( char * ) ( _table -> UINT8_table + 1224 ) ; strcpy ( _dline -> compilerData
-> block [ 7 ] . name ,
"hybrid_powertrain_P5/Transmission/Differential1/Planet-Planet1" ) ; _dline
-> compilerData -> block [ 7 ] . visibleName = ( char * ) ( _table ->
UINT8_table + 1287 ) ; strcpy ( _dline -> compilerData -> block [ 7 ] .
visibleName , "hybrid_powertrain_P5/Transmission/Differential1" ) ; _dline ->
compilerData -> block [ 7 ] . type = DRIVEPLANETPLANET ; _dline ->
compilerData -> block [ 7 ] . flange = _table -> INT32_table + 13 ; _dline ->
compilerData -> block [ 7 ] . flange [ 0 ] = 5 ; _dline -> compilerData ->
block [ 7 ] . flange [ 1 ] = 6 ; _dline -> compilerData -> block [ 7 ] .
flange [ 2 ] = 8 ; _dline -> compilerData -> block [ 7 ] . planetPlanet =
_table -> DrivePlanetPlanet_table + 1 ; _dline -> compilerData -> block [ 7 ]
. planetPlanet [ 0 ] . sunFlange = 2 ; _dline -> compilerData -> block [ 7 ]
. planetPlanet [ 0 ] . planetFlange = 1 ; _dline -> compilerData -> block [ 7
] . planetPlanet [ 0 ] . ratio = 1.0 ; _dline -> compilerData -> block [ 8 ]
. numFlanges = 2 ; _dline -> compilerData -> block [ 8 ] . numParameters = 1
; _dline -> compilerData -> block [ 8 ] . parameter = _table ->
DriveParameter_table + 4 ; _dline -> compilerData -> block [ 8 ] . parameter
[ 0 ] . type = DRIVERTP_SIMPLEGEARRATIO ; _dline -> compilerData -> block [ 8
] . parameter [ 0 ] . flag = ( char * ) ( _table -> UINT8_table + 1335 ) ;
strcpy ( _dline -> compilerData -> block [ 8 ] . parameter [ 0 ] . flag ,
"drive_cc53af08GearRatio" ) ; _dline -> compilerData -> block [ 8 ] .
numSimpleGear = 1 ; _dline -> compilerData -> block [ 8 ] . name = ( char * )
( _table -> UINT8_table + 1359 ) ; strcpy ( _dline -> compilerData -> block [
8 ] . name , "hybrid_powertrain_P5/Transmission/Differential1/Simple Gear" )
; _dline -> compilerData -> block [ 8 ] . visibleName = ( char * ) ( _table
-> UINT8_table + 1419 ) ; strcpy ( _dline -> compilerData -> block [ 8 ] .
visibleName , "hybrid_powertrain_P5/Transmission/Differential1" ) ; _dline ->
compilerData -> block [ 8 ] . type = DRIVESIMPLEGEAR ; _dline -> compilerData
-> block [ 8 ] . flange = _table -> INT32_table + 16 ; _dline -> compilerData
-> block [ 8 ] . flange [ 0 ] = 6 ; _dline -> compilerData -> block [ 8 ] .
flange [ 1 ] = 7 ; _dline -> compilerData -> block [ 8 ] . simpleGear =
_table -> DriveSimpleGear_table + 2 ; _dline -> compilerData -> block [ 8 ] .
simpleGear [ 0 ] . reversing = TRUE ; _dline -> compilerData -> block [ 8 ] .
simpleGear [ 0 ] . inputFlange = 1 ; _dline -> compilerData -> block [ 8 ] .
simpleGear [ 0 ] . ratio = 1.0 ; _dline -> compilerData -> block [ 9 ] .
numFlanges = 2 ; _dline -> compilerData -> block [ 9 ] . numParameters = 1 ;
_dline -> compilerData -> block [ 9 ] . parameter = _table ->
DriveParameter_table + 5 ; _dline -> compilerData -> block [ 9 ] . parameter
[ 0 ] . type = DRIVERTP_SIMPLEGEARRATIO ; _dline -> compilerData -> block [ 9
] . parameter [ 0 ] . flag = ( char * ) ( _table -> UINT8_table + 1467 ) ;
strcpy ( _dline -> compilerData -> block [ 9 ] . parameter [ 0 ] . flag ,
"drive_4667a9a2GearRatio" ) ; _dline -> compilerData -> block [ 9 ] .
numSimpleGear = 1 ; _dline -> compilerData -> block [ 9 ] . name = ( char * )
( _table -> UINT8_table + 1491 ) ; strcpy ( _dline -> compilerData -> block [
9 ] . name , "hybrid_powertrain_P5/Transmission/Differential1/Simple Gear2" )
; _dline -> compilerData -> block [ 9 ] . visibleName = ( char * ) ( _table
-> UINT8_table + 1552 ) ; strcpy ( _dline -> compilerData -> block [ 9 ] .
visibleName , "hybrid_powertrain_P5/Transmission/Differential1" ) ; _dline ->
compilerData -> block [ 9 ] . type = DRIVESIMPLEGEAR ; _dline -> compilerData
-> block [ 9 ] . flange = _table -> INT32_table + 18 ; _dline -> compilerData
-> block [ 9 ] . flange [ 0 ] = 8 ; _dline -> compilerData -> block [ 9 ] .
flange [ 1 ] = 9 ; _dline -> compilerData -> block [ 9 ] . simpleGear =
_table -> DriveSimpleGear_table + 3 ; _dline -> compilerData -> block [ 9 ] .
simpleGear [ 0 ] . reversing = TRUE ; _dline -> compilerData -> block [ 9 ] .
simpleGear [ 0 ] . outputFlange = 1 ; _dline -> compilerData -> block [ 9 ] .
simpleGear [ 0 ] . ratio = 1.0 ; _dline -> compilerData -> block [ 10 ] .
numFlanges = 2 ; _dline -> compilerData -> block [ 10 ] . numClutch = 1 ;
_dline -> compilerData -> block [ 10 ] . name = ( char * ) ( _table ->
UINT8_table + 1600 ) ; strcpy ( _dline -> compilerData -> block [ 10 ] . name
,
 "hybrid_powertrain_P5/Transmission/Drive\\\\nClutch/Fundamental\\\\nFriction Clutch"
) ; _dline -> compilerData -> block [ 10 ] . visibleName = ( char * ) (
_table -> UINT8_table + 1675 ) ; strcpy ( _dline -> compilerData -> block [
10 ] . visibleName , "hybrid_powertrain_P5/Transmission/Drive\\\\nClutch" ) ;
_dline -> compilerData -> block [ 10 ] . type = DRIVECLUTCH ; _dline ->
compilerData -> block [ 10 ] . flange = _table -> INT32_table + 20 ; _dline
-> compilerData -> block [ 10 ] . flange [ 0 ] = 9 ; _dline -> compilerData
-> block [ 10 ] . flange [ 1 ] = 10 ; _dline -> compilerData -> block [ 10 ]
. clutch = _table -> DriveClutch_table + 2 ; _dline -> compilerData -> block
[ 10 ] . clutch [ 0 ] . mode = DRIVEUNLOCKED ; _dline -> compilerData ->
block [ 10 ] . clutch [ 0 ] . inputFlange = 1 ; _dline -> compilerData ->
block [ 10 ] . clutch [ 0 ] . modeFlag = ( char * ) ( _table -> UINT8_table +
1722 ) ; strcpy ( _dline -> compilerData -> block [ 10 ] . clutch [ 0 ] .
modeFlag , "drive_cd1ef77mode" ) ; _dline -> compilerData -> block [ 10 ] .
clutch [ 0 ] . velocityFlag = ( char * ) ( _table -> UINT8_table + 1740 ) ;
strcpy ( _dline -> compilerData -> block [ 10 ] . clutch [ 0 ] . velocityFlag
, "drive_cd1ef77velocity" ) ; _dline -> compilerData -> block [ 10 ] . clutch
[ 0 ] . kineticFrictionTorqueFlag = ( char * ) ( _table -> UINT8_table + 1762
) ; strcpy ( _dline -> compilerData -> block [ 10 ] . clutch [ 0 ] .
kineticFrictionTorqueFlag , "drive_cd1ef77kinFricTor" ) ; _dline ->
compilerData -> block [ 10 ] . clutch [ 0 ] . posStaticFricPeakFlag = ( char
* ) ( _table -> UINT8_table + 1786 ) ; strcpy ( _dline -> compilerData ->
block [ 10 ] . clutch [ 0 ] . posStaticFricPeakFlag ,
"drive_cd1ef77posStaticFricPeak" ) ; _dline -> compilerData -> block [ 10 ] .
clutch [ 0 ] . negStaticFricPeakFlag = ( char * ) ( _table -> UINT8_table +
1817 ) ; strcpy ( _dline -> compilerData -> block [ 10 ] . clutch [ 0 ] .
negStaticFricPeakFlag , "drive_cd1ef77negStaticFricPeak" ) ; _dline ->
compilerData -> block [ 10 ] . clutch [ 0 ] . outputMode = TRUE ; _dline ->
compilerData -> block [ 10 ] . clutch [ 0 ] . lockAtStart = TRUE ; _dline ->
compilerData -> block [ 10 ] . clutch [ 0 ] . velocityTolerance = 0.001 ;
_dline -> compilerData -> block [ 10 ] . clutch [ 0 ] .
automaticVarStepVelocityTolerance = TRUE ; _dline -> compilerData -> block [
10 ] . clutch [ 0 ] . useDefaultVelocityTolerance = TRUE ; _dline ->
compilerData -> block [ 11 ] . numFlanges = 1 ; _dline -> compilerData ->
block [ 11 ] . numWeld = 1 ; _dline -> compilerData -> block [ 11 ] . name =
( char * ) ( _table -> UINT8_table + 1848 ) ; strcpy ( _dline -> compilerData
-> block [ 11 ] . name ,
"hybrid_powertrain_P5/Transmission/Housing/Housing\\\\nInternal" ) ; _dline
-> compilerData -> block [ 11 ] . visibleName = ( char * ) ( _table ->
UINT8_table + 1907 ) ; strcpy ( _dline -> compilerData -> block [ 11 ] .
visibleName , "hybrid_powertrain_P5/Transmission/Housing" ) ; _dline ->
compilerData -> block [ 11 ] . type = DRIVEWELD ; _dline -> compilerData ->
block [ 11 ] . flange = _table -> INT32_table + 22 ; _dline -> compilerData
-> block [ 11 ] . flange [ 0 ] = 10 ; _dline -> compilerData -> block [ 11 ]
. weld = _table -> DriveWeld_table + 1 ; _dline -> compilerData -> block [ 11
] . weld [ 0 ] . isWeld = TRUE ; _dline -> compilerData -> block [ 12 ] .
numFlanges = 1 ; _dline -> compilerData -> block [ 12 ] . numParameters = 2 ;
_dline -> compilerData -> block [ 12 ] . parameter = _table ->
DriveParameter_table + 6 ; _dline -> compilerData -> block [ 12 ] . parameter
[ 0 ] . type = DRIVERTP_INERTIA ; _dline -> compilerData -> block [ 12 ] .
parameter [ 0 ] . flag = ( char * ) ( _table -> UINT8_table + 1949 ) ; strcpy
( _dline -> compilerData -> block [ 12 ] . parameter [ 0 ] . flag ,
"drive_cac21059Inertia" ) ; _dline -> compilerData -> block [ 12 ] .
parameter [ 1 ] . type = DRIVERTP_INITIALCONDITION ; _dline -> compilerData
-> block [ 12 ] . parameter [ 1 ] . flag = ( char * ) ( _table -> UINT8_table
+ 1971 ) ; strcpy ( _dline -> compilerData -> block [ 12 ] . parameter [ 1 ]
. flag , "drive_cac21059InitialCondition" ) ; _dline -> compilerData -> block
[ 12 ] . numInertia = 1 ; _dline -> compilerData -> block [ 12 ] . name = (
char * ) ( _table -> UINT8_table + 2002 ) ; strcpy ( _dline -> compilerData
-> block [ 12 ] . name ,
"hybrid_powertrain_P5/Electric Drive/DC Motor/Shaft\\\\nInertia" ) ; _dline
-> compilerData -> block [ 12 ] . visibleName = ( char * ) ( _table ->
UINT8_table + 2061 ) ; strcpy ( _dline -> compilerData -> block [ 12 ] .
visibleName ,
"hybrid_powertrain_P5/Electric Drive/DC Motor/Shaft\\\\nInertia" ) ; _dline
-> compilerData -> block [ 12 ] . type = DRIVEINERTIA ; _dline ->
compilerData -> block [ 12 ] . flange = _table -> INT32_table + 23 ; _dline
-> compilerData -> block [ 12 ] . flange [ 0 ] = 9 ; _dline -> compilerData
-> block [ 12 ] . inertia = _table -> DriveInertia_table ; _dline ->
compilerData -> block [ 12 ] . inertia [ 0 ] . inertia = 0.001 ; _dline ->
compilerData -> block [ 13 ] . numFlanges = 1 ; _dline -> compilerData ->
block [ 13 ] . numParameters = 2 ; _dline -> compilerData -> block [ 13 ] .
parameter = _table -> DriveParameter_table + 8 ; _dline -> compilerData ->
block [ 13 ] . parameter [ 0 ] . type = DRIVERTP_INERTIA ; _dline ->
compilerData -> block [ 13 ] . parameter [ 0 ] . flag = ( char * ) ( _table
-> UINT8_table + 2120 ) ; strcpy ( _dline -> compilerData -> block [ 13 ] .
parameter [ 0 ] . flag , "drive_cd0455baInertia" ) ; _dline -> compilerData
-> block [ 13 ] . parameter [ 1 ] . type = DRIVERTP_INITIALCONDITION ; _dline
-> compilerData -> block [ 13 ] . parameter [ 1 ] . flag = ( char * ) (
_table -> UINT8_table + 2142 ) ; strcpy ( _dline -> compilerData -> block [
13 ] . parameter [ 1 ] . flag , "drive_cd0455baInitialCondition" ) ; _dline
-> compilerData -> block [ 13 ] . numInertia = 1 ; _dline -> compilerData ->
block [ 13 ] . name = ( char * ) ( _table -> UINT8_table + 2173 ) ; strcpy (
_dline -> compilerData -> block [ 13 ] . name ,
"hybrid_powertrain_P5/Transmission/Inertia1" ) ; _dline -> compilerData ->
block [ 13 ] . visibleName = ( char * ) ( _table -> UINT8_table + 2216 ) ;
strcpy ( _dline -> compilerData -> block [ 13 ] . visibleName ,
"hybrid_powertrain_P5/Transmission/Inertia1" ) ; _dline -> compilerData ->
block [ 13 ] . type = DRIVEINERTIA ; _dline -> compilerData -> block [ 13 ] .
flange = _table -> INT32_table + 24 ; _dline -> compilerData -> block [ 13 ]
. flange [ 0 ] = 9 ; _dline -> compilerData -> block [ 13 ] . inertia =
_table -> DriveInertia_table + 1 ; _dline -> compilerData -> block [ 13 ] .
inertia [ 0 ] . inertia = 5.0 ; _dline -> compilerData -> block [ 14 ] .
numFlanges = 1 ; _dline -> compilerData -> block [ 14 ] . numTransducer = 1 ;
_dline -> compilerData -> block [ 14 ] . name = ( char * ) ( _table ->
UINT8_table + 2259 ) ; strcpy ( _dline -> compilerData -> block [ 14 ] . name
, "hybrid_powertrain_P5/Electric Drive/DC Motor/Motion\\\\nSensor/Transducer"
) ; _dline -> compilerData -> block [ 14 ] . visibleName = ( char * ) (
_table -> UINT8_table + 2329 ) ; strcpy ( _dline -> compilerData -> block [
14 ] . visibleName ,
"hybrid_powertrain_P5/Electric Drive/DC Motor/Motion\\\\nSensor" ) ; _dline
-> compilerData -> block [ 14 ] . type = DRIVETRANSDUCER ; _dline ->
compilerData -> block [ 14 ] . flange = _table -> INT32_table + 25 ; _dline
-> compilerData -> block [ 14 ] . flange [ 0 ] = 9 ; _dline -> compilerData
-> block [ 14 ] . transducer = _table -> DriveTransducer_table ; _dline ->
compilerData -> block [ 14 ] . transducer [ 0 ] . numSignals = 2 ; _dline ->
compilerData -> block [ 14 ] . transducer [ 0 ] . positionFlag = ( char * ) (
_table -> UINT8_table + 2388 ) ; strcpy ( _dline -> compilerData -> block [
14 ] . transducer [ 0 ] . positionFlag , "Undefined" ) ; _dline ->
compilerData -> block [ 14 ] . transducer [ 0 ] . velocityFlag = ( char * ) (
_table -> UINT8_table + 2398 ) ; strcpy ( _dline -> compilerData -> block [
14 ] . transducer [ 0 ] . velocityFlag , "Undefined" ) ; _dline ->
compilerData -> block [ 14 ] . transducer [ 0 ] . accelerationFlag = ( char *
) ( _table -> UINT8_table + 2408 ) ; strcpy ( _dline -> compilerData -> block
[ 14 ] . transducer [ 0 ] . accelerationFlag , "Undefined" ) ; _dline ->
compilerData -> block [ 14 ] . transducer [ 0 ] . signal = _table ->
DriveSignal_table ; _dline -> compilerData -> block [ 14 ] . transducer [ 0 ]
. signal [ 0 ] . type = DRIVEVELOCITY ; _dline -> compilerData -> block [ 14
] . transducer [ 0 ] . signal [ 0 ] . flag = ( char * ) ( _table ->
UINT8_table + 2418 ) ; strcpy ( _dline -> compilerData -> block [ 14 ] .
transducer [ 0 ] . signal [ 0 ] . flag , "drive_2d1572ddVelocity" ) ; _dline
-> compilerData -> block [ 14 ] . transducer [ 0 ] . signal [ 1 ] . type =
DRIVEACCELERATION ; _dline -> compilerData -> block [ 14 ] . transducer [ 0 ]
. signal [ 1 ] . flag = ( char * ) ( _table -> UINT8_table + 2441 ) ; strcpy
( _dline -> compilerData -> block [ 14 ] . transducer [ 0 ] . signal [ 1 ] .
flag , "drive_2d1572ddAcceleration" ) ; _dline -> compilerData -> block [ 15
] . numFlanges = 1 ; _dline -> compilerData -> block [ 15 ] . numTransducer =
1 ; _dline -> compilerData -> block [ 15 ] . name = ( char * ) ( _table ->
UINT8_table + 2468 ) ; strcpy ( _dline -> compilerData -> block [ 15 ] . name
,
"hybrid_powertrain_P5/Electric Drive/DC Motor/Torque\\\\nActuator/Transducer"
) ; _dline -> compilerData -> block [ 15 ] . visibleName = ( char * ) (
_table -> UINT8_table + 2540 ) ; strcpy ( _dline -> compilerData -> block [
15 ] . visibleName ,
"hybrid_powertrain_P5/Electric Drive/DC Motor/Torque\\\\nActuator" ) ; _dline
-> compilerData -> block [ 15 ] . type = DRIVETRANSDUCER ; _dline ->
compilerData -> block [ 15 ] . flange = _table -> INT32_table + 26 ; _dline
-> compilerData -> block [ 15 ] . flange [ 0 ] = 9 ; _dline -> compilerData
-> block [ 15 ] . transducer = _table -> DriveTransducer_table + 1 ; _dline
-> compilerData -> block [ 15 ] . transducer [ 0 ] . numSignals = 1 ; _dline
-> compilerData -> block [ 15 ] . transducer [ 0 ] . positionFlag = ( char *
) ( _table -> UINT8_table + 2601 ) ; strcpy ( _dline -> compilerData -> block
[ 15 ] . transducer [ 0 ] . positionFlag , "Undefined" ) ; _dline ->
compilerData -> block [ 15 ] . transducer [ 0 ] . velocityFlag = ( char * ) (
_table -> UINT8_table + 2611 ) ; strcpy ( _dline -> compilerData -> block [
15 ] . transducer [ 0 ] . velocityFlag , "Undefined" ) ; _dline ->
compilerData -> block [ 15 ] . transducer [ 0 ] . accelerationFlag = ( char *
) ( _table -> UINT8_table + 2621 ) ; strcpy ( _dline -> compilerData -> block
[ 15 ] . transducer [ 0 ] . accelerationFlag , "Undefined" ) ; _dline ->
compilerData -> block [ 15 ] . transducer [ 0 ] . signal = _table ->
DriveSignal_table + 2 ; _dline -> compilerData -> block [ 15 ] . transducer [
0 ] . signal [ 0 ] . type = DRIVEEXTERNALTORQUE ; _dline -> compilerData ->
block [ 15 ] . transducer [ 0 ] . signal [ 0 ] . flag = ( char * ) ( _table
-> UINT8_table + 2631 ) ; strcpy ( _dline -> compilerData -> block [ 15 ] .
transducer [ 0 ] . signal [ 0 ] . flag , "drive_ac179e83Tor" ) ; _dline ->
compilerData -> block [ 16 ] . numFlanges = 1 ; _dline -> compilerData ->
block [ 16 ] . numTransducer = 1 ; _dline -> compilerData -> block [ 16 ] .
name = ( char * ) ( _table -> UINT8_table + 2649 ) ; strcpy ( _dline ->
compilerData -> block [ 16 ] . name ,
"hybrid_powertrain_P5/Transmission/Subsystem/Motion Sensor3/Transducer" ) ;
_dline -> compilerData -> block [ 16 ] . visibleName = ( char * ) ( _table ->
UINT8_table + 2719 ) ; strcpy ( _dline -> compilerData -> block [ 16 ] .
visibleName , "hybrid_powertrain_P5/Transmission/Subsystem/Motion Sensor3" )
; _dline -> compilerData -> block [ 16 ] . type = DRIVETRANSDUCER ; _dline ->
compilerData -> block [ 16 ] . flange = _table -> INT32_table + 27 ; _dline
-> compilerData -> block [ 16 ] . flange [ 0 ] = 9 ; _dline -> compilerData
-> block [ 16 ] . transducer = _table -> DriveTransducer_table + 2 ; _dline
-> compilerData -> block [ 16 ] . transducer [ 0 ] . numSignals = 2 ; _dline
-> compilerData -> block [ 16 ] . transducer [ 0 ] . positionFlag = ( char *
) ( _table -> UINT8_table + 2778 ) ; strcpy ( _dline -> compilerData -> block
[ 16 ] . transducer [ 0 ] . positionFlag , "Undefined" ) ; _dline ->
compilerData -> block [ 16 ] . transducer [ 0 ] . velocityFlag = ( char * ) (
_table -> UINT8_table + 2788 ) ; strcpy ( _dline -> compilerData -> block [
16 ] . transducer [ 0 ] . velocityFlag , "Undefined" ) ; _dline ->
compilerData -> block [ 16 ] . transducer [ 0 ] . accelerationFlag = ( char *
) ( _table -> UINT8_table + 2798 ) ; strcpy ( _dline -> compilerData -> block
[ 16 ] . transducer [ 0 ] . accelerationFlag , "Undefined" ) ; _dline ->
compilerData -> block [ 16 ] . transducer [ 0 ] . signal = _table ->
DriveSignal_table + 3 ; _dline -> compilerData -> block [ 16 ] . transducer [
0 ] . signal [ 0 ] . type = DRIVEVELOCITY ; _dline -> compilerData -> block [
16 ] . transducer [ 0 ] . signal [ 0 ] . flag = ( char * ) ( _table ->
UINT8_table + 2808 ) ; strcpy ( _dline -> compilerData -> block [ 16 ] .
transducer [ 0 ] . signal [ 0 ] . flag , "drive_2c3120eVelocity" ) ; _dline
-> compilerData -> block [ 16 ] . transducer [ 0 ] . signal [ 1 ] . type =
DRIVEACCELERATION ; _dline -> compilerData -> block [ 16 ] . transducer [ 0 ]
. signal [ 1 ] . flag = ( char * ) ( _table -> UINT8_table + 2830 ) ; strcpy
( _dline -> compilerData -> block [ 16 ] . transducer [ 0 ] . signal [ 1 ] .
flag , "drive_2c3120eAcceleration" ) ; _dline -> compilerData -> block [ 17 ]
. numFlanges = 2 ; _dline -> compilerData -> block [ 17 ] . numParameters = 1
; _dline -> compilerData -> block [ 17 ] . parameter = _table ->
DriveParameter_table + 10 ; _dline -> compilerData -> block [ 17 ] .
parameter [ 0 ] . type = DRIVERTP_SIMPLEGEARRATIO ; _dline -> compilerData ->
block [ 17 ] . parameter [ 0 ] . flag = ( char * ) ( _table -> UINT8_table +
2856 ) ; strcpy ( _dline -> compilerData -> block [ 17 ] . parameter [ 0 ] .
flag , "drive_df6ef818GearRatio" ) ; _dline -> compilerData -> block [ 17 ] .
numSimpleGear = 1 ; _dline -> compilerData -> block [ 17 ] . name = ( char *
) ( _table -> UINT8_table + 2880 ) ; strcpy ( _dline -> compilerData -> block
[ 17 ] . name ,
"hybrid_powertrain_P5/Transmission/Differential1/Simple Gear1" ) ; _dline ->
compilerData -> block [ 17 ] . visibleName = ( char * ) ( _table ->
UINT8_table + 2941 ) ; strcpy ( _dline -> compilerData -> block [ 17 ] .
visibleName , "hybrid_powertrain_P5/Transmission/Differential1" ) ; _dline ->
compilerData -> block [ 17 ] . type = DRIVESIMPLEGEAR ; _dline ->
compilerData -> block [ 17 ] . flange = _table -> INT32_table + 28 ; _dline
-> compilerData -> block [ 17 ] . flange [ 0 ] = 5 ; _dline -> compilerData
-> block [ 17 ] . flange [ 1 ] = 11 ; _dline -> compilerData -> block [ 17 ]
. simpleGear = _table -> DriveSimpleGear_table + 4 ; _dline -> compilerData
-> block [ 17 ] . simpleGear [ 0 ] . reversing = TRUE ; _dline ->
compilerData -> block [ 17 ] . simpleGear [ 0 ] . inputFlange = 1 ; _dline ->
compilerData -> block [ 17 ] . simpleGear [ 0 ] . ratio = 2.0 ; _dline ->
compilerData -> block [ 18 ] . numFlanges = 2 ; _dline -> compilerData ->
block [ 18 ] . numClutch = 1 ; _dline -> compilerData -> block [ 18 ] . name
= ( char * ) ( _table -> UINT8_table + 2989 ) ; strcpy ( _dline ->
compilerData -> block [ 18 ] . name ,
 "hybrid_powertrain_P5/Transmission/Brake/Controllable\\\\nFriction Clutch/Fundamental\\\\nFriction Clutch"
) ; _dline -> compilerData -> block [ 18 ] . visibleName = ( char * ) (
_table -> UINT8_table + 3086 ) ; strcpy ( _dline -> compilerData -> block [
18 ] . visibleName ,
"hybrid_powertrain_P5/Transmission/Brake/Controllable\\\\nFriction Clutch" )
; _dline -> compilerData -> block [ 18 ] . type = DRIVECLUTCH ; _dline ->
compilerData -> block [ 18 ] . flange = _table -> INT32_table + 30 ; _dline
-> compilerData -> block [ 18 ] . flange [ 0 ] = 11 ; _dline -> compilerData
-> block [ 18 ] . flange [ 1 ] = 12 ; _dline -> compilerData -> block [ 18 ]
. clutch = _table -> DriveClutch_table + 3 ; _dline -> compilerData -> block
[ 18 ] . clutch [ 0 ] . mode = DRIVEUNLOCKED ; _dline -> compilerData ->
block [ 18 ] . clutch [ 0 ] . outputFlange = 1 ; _dline -> compilerData ->
block [ 18 ] . clutch [ 0 ] . modeFlag = ( char * ) ( _table -> UINT8_table +
3155 ) ; strcpy ( _dline -> compilerData -> block [ 18 ] . clutch [ 0 ] .
modeFlag , "drive_cac76a3emode" ) ; _dline -> compilerData -> block [ 18 ] .
clutch [ 0 ] . velocityFlag = ( char * ) ( _table -> UINT8_table + 3174 ) ;
strcpy ( _dline -> compilerData -> block [ 18 ] . clutch [ 0 ] . velocityFlag
, "drive_cac76a3evelocity" ) ; _dline -> compilerData -> block [ 18 ] .
clutch [ 0 ] . kineticFrictionTorqueFlag = ( char * ) ( _table -> UINT8_table
+ 3197 ) ; strcpy ( _dline -> compilerData -> block [ 18 ] . clutch [ 0 ] .
kineticFrictionTorqueFlag , "drive_cac76a3ekinFricTor" ) ; _dline ->
compilerData -> block [ 18 ] . clutch [ 0 ] . posStaticFricPeakFlag = ( char
* ) ( _table -> UINT8_table + 3222 ) ; strcpy ( _dline -> compilerData ->
block [ 18 ] . clutch [ 0 ] . posStaticFricPeakFlag ,
"drive_cac76a3eposStaticFricPeak" ) ; _dline -> compilerData -> block [ 18 ]
. clutch [ 0 ] . negStaticFricPeakFlag = ( char * ) ( _table -> UINT8_table +
3254 ) ; strcpy ( _dline -> compilerData -> block [ 18 ] . clutch [ 0 ] .
negStaticFricPeakFlag , "drive_cac76a3enegStaticFricPeak" ) ; _dline ->
compilerData -> block [ 18 ] . clutch [ 0 ] . outputMode = TRUE ; _dline ->
compilerData -> block [ 18 ] . clutch [ 0 ] . velocityTolerance = 0.001 ;
_dline -> compilerData -> block [ 18 ] . clutch [ 0 ] .
automaticVarStepVelocityTolerance = TRUE ; _dline -> compilerData -> block [
18 ] . clutch [ 0 ] . useDefaultVelocityTolerance = TRUE ; _dline ->
compilerData -> block [ 19 ] . numFlanges = 1 ; _dline -> compilerData ->
block [ 19 ] . numWeld = 1 ; _dline -> compilerData -> block [ 19 ] . name =
( char * ) ( _table -> UINT8_table + 3286 ) ; strcpy ( _dline -> compilerData
-> block [ 19 ] . name ,
"hybrid_powertrain_P5/Transmission/Brake/Housing/Housing\\\\nInternal" ) ;
_dline -> compilerData -> block [ 19 ] . visibleName = ( char * ) ( _table ->
UINT8_table + 3351 ) ; strcpy ( _dline -> compilerData -> block [ 19 ] .
visibleName , "hybrid_powertrain_P5/Transmission/Brake/Housing" ) ; _dline ->
compilerData -> block [ 19 ] . type = DRIVEWELD ; _dline -> compilerData ->
block [ 19 ] . flange = _table -> INT32_table + 32 ; _dline -> compilerData
-> block [ 19 ] . flange [ 0 ] = 12 ; _dline -> compilerData -> block [ 19 ]
. weld = _table -> DriveWeld_table + 2 ; _dline -> compilerData -> block [ 19
] . weld [ 0 ] . isWeld = TRUE ; _dline -> compilerData -> block [ 20 ] .
numFlanges = 1 ; _dline -> compilerData -> block [ 20 ] . numParameters = 2 ;
_dline -> compilerData -> block [ 20 ] . parameter = _table ->
DriveParameter_table + 11 ; _dline -> compilerData -> block [ 20 ] .
parameter [ 0 ] . type = DRIVERTP_INERTIA ; _dline -> compilerData -> block [
20 ] . parameter [ 0 ] . flag = ( char * ) ( _table -> UINT8_table + 3399 ) ;
strcpy ( _dline -> compilerData -> block [ 20 ] . parameter [ 0 ] . flag ,
"drive_540d0400Inertia" ) ; _dline -> compilerData -> block [ 20 ] .
parameter [ 1 ] . type = DRIVERTP_INITIALCONDITION ; _dline -> compilerData
-> block [ 20 ] . parameter [ 1 ] . flag = ( char * ) ( _table -> UINT8_table
+ 3421 ) ; strcpy ( _dline -> compilerData -> block [ 20 ] . parameter [ 1 ]
. flag , "drive_540d0400InitialCondition" ) ; _dline -> compilerData -> block
[ 20 ] . numInertia = 1 ; _dline -> compilerData -> block [ 20 ] . name = (
char * ) ( _table -> UINT8_table + 3452 ) ; strcpy ( _dline -> compilerData
-> block [ 20 ] . name , "hybrid_powertrain_P5/Transmission/Inertia2" ) ;
_dline -> compilerData -> block [ 20 ] . visibleName = ( char * ) ( _table ->
UINT8_table + 3495 ) ; strcpy ( _dline -> compilerData -> block [ 20 ] .
visibleName , "hybrid_powertrain_P5/Transmission/Inertia2" ) ; _dline ->
compilerData -> block [ 20 ] . type = DRIVEINERTIA ; _dline -> compilerData
-> block [ 20 ] . flange = _table -> INT32_table + 33 ; _dline ->
compilerData -> block [ 20 ] . flange [ 0 ] = 11 ; _dline -> compilerData ->
block [ 20 ] . inertia = _table -> DriveInertia_table + 2 ; _dline ->
compilerData -> block [ 20 ] . inertia [ 0 ] . inertia = 100.0 ; _dline ->
compilerData -> block [ 21 ] . numFlanges = 2 ; _dline -> compilerData ->
block [ 21 ] . numParameters = 1 ; _dline -> compilerData -> block [ 21 ] .
parameter = _table -> DriveParameter_table + 13 ; _dline -> compilerData ->
block [ 21 ] . parameter [ 0 ] . type = DRIVERTP_SIMPLEGEARRATIO ; _dline ->
compilerData -> block [ 21 ] . parameter [ 0 ] . flag = ( char * ) ( _table
-> UINT8_table + 3538 ) ; strcpy ( _dline -> compilerData -> block [ 21 ] .
parameter [ 0 ] . flag , "drive_61b9e861GearRatio" ) ; _dline -> compilerData
-> block [ 21 ] . numSimpleGear = 1 ; _dline -> compilerData -> block [ 21 ]
. name = ( char * ) ( _table -> UINT8_table + 3562 ) ; strcpy ( _dline ->
compilerData -> block [ 21 ] . name ,
"hybrid_powertrain_P5/Transmission/Differential/Simple Gear1" ) ; _dline ->
compilerData -> block [ 21 ] . visibleName = ( char * ) ( _table ->
UINT8_table + 3622 ) ; strcpy ( _dline -> compilerData -> block [ 21 ] .
visibleName , "hybrid_powertrain_P5/Transmission/Differential" ) ; _dline ->
compilerData -> block [ 21 ] . type = DRIVESIMPLEGEAR ; _dline ->
compilerData -> block [ 21 ] . flange = _table -> INT32_table + 34 ; _dline
-> compilerData -> block [ 21 ] . flange [ 0 ] = 11 ; _dline -> compilerData
-> block [ 21 ] . flange [ 1 ] = 13 ; _dline -> compilerData -> block [ 21 ]
. simpleGear = _table -> DriveSimpleGear_table + 5 ; _dline -> compilerData
-> block [ 21 ] . simpleGear [ 0 ] . reversing = TRUE ; _dline ->
compilerData -> block [ 21 ] . simpleGear [ 0 ] . outputFlange = 1 ; _dline
-> compilerData -> block [ 21 ] . simpleGear [ 0 ] . ratio = 2.0 ; _dline ->
compilerData -> block [ 22 ] . numFlanges = 3 ; _dline -> compilerData ->
block [ 22 ] . numParameters = 1 ; _dline -> compilerData -> block [ 22 ] .
parameter = _table -> DriveParameter_table + 14 ; _dline -> compilerData ->
block [ 22 ] . parameter [ 0 ] . type = DRIVERTP_PLANETPLANETGEARRATIO ;
_dline -> compilerData -> block [ 22 ] . parameter [ 0 ] . flag = ( char * )
( _table -> UINT8_table + 3669 ) ; strcpy ( _dline -> compilerData -> block [
22 ] . parameter [ 0 ] . flag , "drive_a561028dPlanetPlanetRatio" ) ; _dline
-> compilerData -> block [ 22 ] . numPlanetPlanet = 1 ; _dline ->
compilerData -> block [ 22 ] . name = ( char * ) ( _table -> UINT8_table +
3701 ) ; strcpy ( _dline -> compilerData -> block [ 22 ] . name ,
"hybrid_powertrain_P5/Transmission/Differential/Planet-Planet" ) ; _dline ->
compilerData -> block [ 22 ] . visibleName = ( char * ) ( _table ->
UINT8_table + 3762 ) ; strcpy ( _dline -> compilerData -> block [ 22 ] .
visibleName , "hybrid_powertrain_P5/Transmission/Differential" ) ; _dline ->
compilerData -> block [ 22 ] . type = DRIVEPLANETPLANET ; _dline ->
compilerData -> block [ 22 ] . flange = _table -> INT32_table + 36 ; _dline
-> compilerData -> block [ 22 ] . flange [ 0 ] = 13 ; _dline -> compilerData
-> block [ 22 ] . flange [ 1 ] = 14 ; _dline -> compilerData -> block [ 22 ]
. flange [ 2 ] = 18 ; _dline -> compilerData -> block [ 22 ] . planetPlanet =
_table -> DrivePlanetPlanet_table + 2 ; _dline -> compilerData -> block [ 22
] . planetPlanet [ 0 ] . sunFlange = 2 ; _dline -> compilerData -> block [ 22
] . planetPlanet [ 0 ] . planetFlange = 1 ; _dline -> compilerData -> block [
22 ] . planetPlanet [ 0 ] . ratio = 1.0 ; _dline -> compilerData -> block [
23 ] . numFlanges = 2 ; _dline -> compilerData -> block [ 23 ] .
numParameters = 1 ; _dline -> compilerData -> block [ 23 ] . parameter =
_table -> DriveParameter_table + 15 ; _dline -> compilerData -> block [ 23 ]
. parameter [ 0 ] . type = DRIVERTP_SIMPLEGEARRATIO ; _dline -> compilerData
-> block [ 23 ] . parameter [ 0 ] . flag = ( char * ) ( _table -> UINT8_table
+ 3809 ) ; strcpy ( _dline -> compilerData -> block [ 23 ] . parameter [ 0 ]
. flag , "drive_1a371226GearRatio" ) ; _dline -> compilerData -> block [ 23 ]
. numSimpleGear = 1 ; _dline -> compilerData -> block [ 23 ] . name = ( char
* ) ( _table -> UINT8_table + 3833 ) ; strcpy ( _dline -> compilerData ->
block [ 23 ] . name ,
"hybrid_powertrain_P5/Transmission/Differential/Simple Gear" ) ; _dline ->
compilerData -> block [ 23 ] . visibleName = ( char * ) ( _table ->
UINT8_table + 3892 ) ; strcpy ( _dline -> compilerData -> block [ 23 ] .
visibleName , "hybrid_powertrain_P5/Transmission/Differential" ) ; _dline ->
compilerData -> block [ 23 ] . type = DRIVESIMPLEGEAR ; _dline ->
compilerData -> block [ 23 ] . flange = _table -> INT32_table + 39 ; _dline
-> compilerData -> block [ 23 ] . flange [ 0 ] = 14 ; _dline -> compilerData
-> block [ 23 ] . flange [ 1 ] = 15 ; _dline -> compilerData -> block [ 23 ]
. simpleGear = _table -> DriveSimpleGear_table + 6 ; _dline -> compilerData
-> block [ 23 ] . simpleGear [ 0 ] . reversing = TRUE ; _dline ->
compilerData -> block [ 23 ] . simpleGear [ 0 ] . outputFlange = 1 ; _dline
-> compilerData -> block [ 23 ] . simpleGear [ 0 ] . ratio = 1.0 ; _dline ->
compilerData -> block [ 24 ] . numFlanges = 3 ; _dline -> compilerData ->
block [ 24 ] . numParameters = 1 ; _dline -> compilerData -> block [ 24 ] .
parameter = _table -> DriveParameter_table + 16 ; _dline -> compilerData ->
block [ 24 ] . parameter [ 0 ] . type = DRIVERTP_PLANETPLANETGEARRATIO ;
_dline -> compilerData -> block [ 24 ] . parameter [ 0 ] . flag = ( char * )
( _table -> UINT8_table + 3939 ) ; strcpy ( _dline -> compilerData -> block [
24 ] . parameter [ 0 ] . flag , "drive_31fd2271PlanetPlanetRatio" ) ; _dline
-> compilerData -> block [ 24 ] . numPlanetPlanet = 1 ; _dline ->
compilerData -> block [ 24 ] . name = ( char * ) ( _table -> UINT8_table +
3971 ) ; strcpy ( _dline -> compilerData -> block [ 24 ] . name ,
"hybrid_powertrain_P5/Transmission/Differential/Planet-Planet1" ) ; _dline ->
compilerData -> block [ 24 ] . visibleName = ( char * ) ( _table ->
UINT8_table + 4033 ) ; strcpy ( _dline -> compilerData -> block [ 24 ] .
visibleName , "hybrid_powertrain_P5/Transmission/Differential" ) ; _dline ->
compilerData -> block [ 24 ] . type = DRIVEPLANETPLANET ; _dline ->
compilerData -> block [ 24 ] . flange = _table -> INT32_table + 41 ; _dline
-> compilerData -> block [ 24 ] . flange [ 0 ] = 15 ; _dline -> compilerData
-> block [ 24 ] . flange [ 1 ] = 16 ; _dline -> compilerData -> block [ 24 ]
. flange [ 2 ] = 13 ; _dline -> compilerData -> block [ 24 ] . planetPlanet =
_table -> DrivePlanetPlanet_table + 3 ; _dline -> compilerData -> block [ 24
] . planetPlanet [ 0 ] . sunFlange = 1 ; _dline -> compilerData -> block [ 24
] . planetPlanet [ 0 ] . carrierFlange = 2 ; _dline -> compilerData -> block
[ 24 ] . planetPlanet [ 0 ] . ratio = 1.0 ; _dline -> compilerData -> block [
25 ] . numFlanges = 2 ; _dline -> compilerData -> block [ 25 ] .
numParameters = 1 ; _dline -> compilerData -> block [ 25 ] . parameter =
_table -> DriveParameter_table + 17 ; _dline -> compilerData -> block [ 25 ]
. parameter [ 0 ] . type = DRIVERTP_SIMPLEGEARRATIO ; _dline -> compilerData
-> block [ 25 ] . parameter [ 0 ] . flag = ( char * ) ( _table -> UINT8_table
+ 4080 ) ; strcpy ( _dline -> compilerData -> block [ 25 ] . parameter [ 0 ]
. flag , "drive_f8b0b9dbGearRatio" ) ; _dline -> compilerData -> block [ 25 ]
. numSimpleGear = 1 ; _dline -> compilerData -> block [ 25 ] . name = ( char
* ) ( _table -> UINT8_table + 4104 ) ; strcpy ( _dline -> compilerData ->
block [ 25 ] . name ,
"hybrid_powertrain_P5/Transmission/Differential/Simple Gear2" ) ; _dline ->
compilerData -> block [ 25 ] . visibleName = ( char * ) ( _table ->
UINT8_table + 4164 ) ; strcpy ( _dline -> compilerData -> block [ 25 ] .
visibleName , "hybrid_powertrain_P5/Transmission/Differential" ) ; _dline ->
compilerData -> block [ 25 ] . type = DRIVESIMPLEGEAR ; _dline ->
compilerData -> block [ 25 ] . flange = _table -> INT32_table + 44 ; _dline
-> compilerData -> block [ 25 ] . flange [ 0 ] = 16 ; _dline -> compilerData
-> block [ 25 ] . flange [ 1 ] = 17 ; _dline -> compilerData -> block [ 25 ]
. simpleGear = _table -> DriveSimpleGear_table + 7 ; _dline -> compilerData
-> block [ 25 ] . simpleGear [ 0 ] . reversing = TRUE ; _dline ->
compilerData -> block [ 25 ] . simpleGear [ 0 ] . outputFlange = 1 ; _dline
-> compilerData -> block [ 25 ] . simpleGear [ 0 ] . ratio = 1.0 ; _dline ->
compilerData -> block [ 26 ] . numFlanges = 1 ; _dline -> compilerData ->
block [ 26 ] . numParameters = 2 ; _dline -> compilerData -> block [ 26 ] .
parameter = _table -> DriveParameter_table + 18 ; _dline -> compilerData ->
block [ 26 ] . parameter [ 0 ] . type = DRIVERTP_INERTIA ; _dline ->
compilerData -> block [ 26 ] . parameter [ 0 ] . flag = ( char * ) ( _table
-> UINT8_table + 4211 ) ; strcpy ( _dline -> compilerData -> block [ 26 ] .
parameter [ 0 ] . flag , "drive_97e8f148Inertia" ) ; _dline -> compilerData
-> block [ 26 ] . parameter [ 1 ] . type = DRIVERTP_INITIALCONDITION ; _dline
-> compilerData -> block [ 26 ] . parameter [ 1 ] . flag = ( char * ) (
_table -> UINT8_table + 4233 ) ; strcpy ( _dline -> compilerData -> block [
26 ] . parameter [ 1 ] . flag , "drive_97e8f148InitialCondition" ) ; _dline
-> compilerData -> block [ 26 ] . numInertia = 1 ; _dline -> compilerData ->
block [ 26 ] . name = ( char * ) ( _table -> UINT8_table + 4264 ) ; strcpy (
_dline -> compilerData -> block [ 26 ] . name ,
"hybrid_powertrain_P5/Left Tire/Inertia" ) ; _dline -> compilerData -> block
[ 26 ] . visibleName = ( char * ) ( _table -> UINT8_table + 4303 ) ; strcpy (
_dline -> compilerData -> block [ 26 ] . visibleName ,
"hybrid_powertrain_P5/Left Tire/Inertia" ) ; _dline -> compilerData -> block
[ 26 ] . type = DRIVEINERTIA ; _dline -> compilerData -> block [ 26 ] .
flange = _table -> INT32_table + 46 ; _dline -> compilerData -> block [ 26 ]
. flange [ 0 ] = 17 ; _dline -> compilerData -> block [ 26 ] . inertia =
_table -> DriveInertia_table + 3 ; _dline -> compilerData -> block [ 26 ] .
inertia [ 0 ] . inertia = 1.0 ; _dline -> compilerData -> block [ 27 ] .
numFlanges = 1 ; _dline -> compilerData -> block [ 27 ] . numTransducer = 1 ;
_dline -> compilerData -> block [ 27 ] . name = ( char * ) ( _table ->
UINT8_table + 4342 ) ; strcpy ( _dline -> compilerData -> block [ 27 ] . name
, "hybrid_powertrain_P5/Left Tire/Motion Sensor/Transducer" ) ; _dline ->
compilerData -> block [ 27 ] . visibleName = ( char * ) ( _table ->
UINT8_table + 4398 ) ; strcpy ( _dline -> compilerData -> block [ 27 ] .
visibleName , "hybrid_powertrain_P5/Left Tire/Motion Sensor" ) ; _dline ->
compilerData -> block [ 27 ] . type = DRIVETRANSDUCER ; _dline ->
compilerData -> block [ 27 ] . flange = _table -> INT32_table + 47 ; _dline
-> compilerData -> block [ 27 ] . flange [ 0 ] = 17 ; _dline -> compilerData
-> block [ 27 ] . transducer = _table -> DriveTransducer_table + 3 ; _dline
-> compilerData -> block [ 27 ] . transducer [ 0 ] . numSignals = 2 ; _dline
-> compilerData -> block [ 27 ] . transducer [ 0 ] . positionFlag = ( char *
) ( _table -> UINT8_table + 4443 ) ; strcpy ( _dline -> compilerData -> block
[ 27 ] . transducer [ 0 ] . positionFlag , "Undefined" ) ; _dline ->
compilerData -> block [ 27 ] . transducer [ 0 ] . velocityFlag = ( char * ) (
_table -> UINT8_table + 4453 ) ; strcpy ( _dline -> compilerData -> block [
27 ] . transducer [ 0 ] . velocityFlag , "Undefined" ) ; _dline ->
compilerData -> block [ 27 ] . transducer [ 0 ] . accelerationFlag = ( char *
) ( _table -> UINT8_table + 4463 ) ; strcpy ( _dline -> compilerData -> block
[ 27 ] . transducer [ 0 ] . accelerationFlag , "Undefined" ) ; _dline ->
compilerData -> block [ 27 ] . transducer [ 0 ] . signal = _table ->
DriveSignal_table + 5 ; _dline -> compilerData -> block [ 27 ] . transducer [
0 ] . signal [ 0 ] . type = DRIVEVELOCITY ; _dline -> compilerData -> block [
27 ] . transducer [ 0 ] . signal [ 0 ] . flag = ( char * ) ( _table ->
UINT8_table + 4473 ) ; strcpy ( _dline -> compilerData -> block [ 27 ] .
transducer [ 0 ] . signal [ 0 ] . flag , "drive_beaa2924Velocity" ) ; _dline
-> compilerData -> block [ 27 ] . transducer [ 0 ] . signal [ 1 ] . type =
DRIVEACCELERATION ; _dline -> compilerData -> block [ 27 ] . transducer [ 0 ]
. signal [ 1 ] . flag = ( char * ) ( _table -> UINT8_table + 4496 ) ; strcpy
( _dline -> compilerData -> block [ 27 ] . transducer [ 0 ] . signal [ 1 ] .
flag , "drive_beaa2924Acceleration" ) ; _dline -> compilerData -> block [ 28
] . numFlanges = 2 ; _dline -> compilerData -> block [ 28 ] . numParameters =
1 ; _dline -> compilerData -> block [ 28 ] . parameter = _table ->
DriveParameter_table + 20 ; _dline -> compilerData -> block [ 28 ] .
parameter [ 0 ] . type = DRIVERTP_SIMPLEGEARRATIO ; _dline -> compilerData ->
block [ 28 ] . parameter [ 0 ] . flag = ( char * ) ( _table -> UINT8_table +
4523 ) ; strcpy ( _dline -> compilerData -> block [ 28 ] . parameter [ 0 ] .
flag , "drive_8fb7894dGearRatio" ) ; _dline -> compilerData -> block [ 28 ] .
numSimpleGear = 1 ; _dline -> compilerData -> block [ 28 ] . name = ( char *
) ( _table -> UINT8_table + 4547 ) ; strcpy ( _dline -> compilerData -> block
[ 28 ] . name , "hybrid_powertrain_P5/Transmission/Differential/Simple Gear3"
) ; _dline -> compilerData -> block [ 28 ] . visibleName = ( char * ) (
_table -> UINT8_table + 4607 ) ; strcpy ( _dline -> compilerData -> block [
28 ] . visibleName , "hybrid_powertrain_P5/Transmission/Differential" ) ;
_dline -> compilerData -> block [ 28 ] . type = DRIVESIMPLEGEAR ; _dline ->
compilerData -> block [ 28 ] . flange = _table -> INT32_table + 48 ; _dline
-> compilerData -> block [ 28 ] . flange [ 0 ] = 18 ; _dline -> compilerData
-> block [ 28 ] . flange [ 1 ] = 19 ; _dline -> compilerData -> block [ 28 ]
. simpleGear = _table -> DriveSimpleGear_table + 8 ; _dline -> compilerData
-> block [ 28 ] . simpleGear [ 0 ] . reversing = TRUE ; _dline ->
compilerData -> block [ 28 ] . simpleGear [ 0 ] . outputFlange = 1 ; _dline
-> compilerData -> block [ 28 ] . simpleGear [ 0 ] . ratio = 1.0 ; _dline ->
compilerData -> block [ 29 ] . numFlanges = 1 ; _dline -> compilerData ->
block [ 29 ] . numParameters = 2 ; _dline -> compilerData -> block [ 29 ] .
parameter = _table -> DriveParameter_table + 21 ; _dline -> compilerData ->
block [ 29 ] . parameter [ 0 ] . type = DRIVERTP_INERTIA ; _dline ->
compilerData -> block [ 29 ] . parameter [ 0 ] . flag = ( char * ) ( _table
-> UINT8_table + 4654 ) ; strcpy ( _dline -> compilerData -> block [ 29 ] .
parameter [ 0 ] . flag , "drive_79afdf4aInertia" ) ; _dline -> compilerData
-> block [ 29 ] . parameter [ 1 ] . type = DRIVERTP_INITIALCONDITION ; _dline
-> compilerData -> block [ 29 ] . parameter [ 1 ] . flag = ( char * ) (
_table -> UINT8_table + 4676 ) ; strcpy ( _dline -> compilerData -> block [
29 ] . parameter [ 1 ] . flag , "drive_79afdf4aInitialCondition" ) ; _dline
-> compilerData -> block [ 29 ] . numInertia = 1 ; _dline -> compilerData ->
block [ 29 ] . name = ( char * ) ( _table -> UINT8_table + 4707 ) ; strcpy (
_dline -> compilerData -> block [ 29 ] . name ,
"hybrid_powertrain_P5/Right Tire/Inertia" ) ; _dline -> compilerData -> block
[ 29 ] . visibleName = ( char * ) ( _table -> UINT8_table + 4747 ) ; strcpy (
_dline -> compilerData -> block [ 29 ] . visibleName ,
"hybrid_powertrain_P5/Right Tire/Inertia" ) ; _dline -> compilerData -> block
[ 29 ] . type = DRIVEINERTIA ; _dline -> compilerData -> block [ 29 ] .
flange = _table -> INT32_table + 50 ; _dline -> compilerData -> block [ 29 ]
. flange [ 0 ] = 19 ; _dline -> compilerData -> block [ 29 ] . inertia =
_table -> DriveInertia_table + 4 ; _dline -> compilerData -> block [ 29 ] .
inertia [ 0 ] . inertia = 1.0 ; _dline -> compilerData -> block [ 30 ] .
numFlanges = 1 ; _dline -> compilerData -> block [ 30 ] . numTransducer = 1 ;
_dline -> compilerData -> block [ 30 ] . name = ( char * ) ( _table ->
UINT8_table + 4787 ) ; strcpy ( _dline -> compilerData -> block [ 30 ] . name
, "hybrid_powertrain_P5/Right Tire/Motion Sensor/Transducer" ) ; _dline ->
compilerData -> block [ 30 ] . visibleName = ( char * ) ( _table ->
UINT8_table + 4844 ) ; strcpy ( _dline -> compilerData -> block [ 30 ] .
visibleName , "hybrid_powertrain_P5/Right Tire/Motion Sensor" ) ; _dline ->
compilerData -> block [ 30 ] . type = DRIVETRANSDUCER ; _dline ->
compilerData -> block [ 30 ] . flange = _table -> INT32_table + 51 ; _dline
-> compilerData -> block [ 30 ] . flange [ 0 ] = 19 ; _dline -> compilerData
-> block [ 30 ] . transducer = _table -> DriveTransducer_table + 4 ; _dline
-> compilerData -> block [ 30 ] . transducer [ 0 ] . numSignals = 2 ; _dline
-> compilerData -> block [ 30 ] . transducer [ 0 ] . positionFlag = ( char *
) ( _table -> UINT8_table + 4890 ) ; strcpy ( _dline -> compilerData -> block
[ 30 ] . transducer [ 0 ] . positionFlag , "Undefined" ) ; _dline ->
compilerData -> block [ 30 ] . transducer [ 0 ] . velocityFlag = ( char * ) (
_table -> UINT8_table + 4900 ) ; strcpy ( _dline -> compilerData -> block [
30 ] . transducer [ 0 ] . velocityFlag , "Undefined" ) ; _dline ->
compilerData -> block [ 30 ] . transducer [ 0 ] . accelerationFlag = ( char *
) ( _table -> UINT8_table + 4910 ) ; strcpy ( _dline -> compilerData -> block
[ 30 ] . transducer [ 0 ] . accelerationFlag , "Undefined" ) ; _dline ->
compilerData -> block [ 30 ] . transducer [ 0 ] . signal = _table ->
DriveSignal_table + 7 ; _dline -> compilerData -> block [ 30 ] . transducer [
0 ] . signal [ 0 ] . type = DRIVEVELOCITY ; _dline -> compilerData -> block [
30 ] . transducer [ 0 ] . signal [ 0 ] . flag = ( char * ) ( _table ->
UINT8_table + 4920 ) ; strcpy ( _dline -> compilerData -> block [ 30 ] .
transducer [ 0 ] . signal [ 0 ] . flag , "drive_cfb8a1e6Velocity" ) ; _dline
-> compilerData -> block [ 30 ] . transducer [ 0 ] . signal [ 1 ] . type =
DRIVEACCELERATION ; _dline -> compilerData -> block [ 30 ] . transducer [ 0 ]
. signal [ 1 ] . flag = ( char * ) ( _table -> UINT8_table + 4943 ) ; strcpy
( _dline -> compilerData -> block [ 30 ] . transducer [ 0 ] . signal [ 1 ] .
flag , "drive_cfb8a1e6Acceleration" ) ; _dline -> compilerData -> block [ 31
] . numFlanges = 1 ; _dline -> compilerData -> block [ 31 ] . numTransducer =
1 ; _dline -> compilerData -> block [ 31 ] . name = ( char * ) ( _table ->
UINT8_table + 4970 ) ; strcpy ( _dline -> compilerData -> block [ 31 ] . name
, "hybrid_powertrain_P5/Transmission/Subsystem/Motion Sensor1/Transducer" ) ;
_dline -> compilerData -> block [ 31 ] . visibleName = ( char * ) ( _table ->
UINT8_table + 5040 ) ; strcpy ( _dline -> compilerData -> block [ 31 ] .
visibleName , "hybrid_powertrain_P5/Transmission/Subsystem/Motion Sensor1" )
; _dline -> compilerData -> block [ 31 ] . type = DRIVETRANSDUCER ; _dline ->
compilerData -> block [ 31 ] . flange = _table -> INT32_table + 52 ; _dline
-> compilerData -> block [ 31 ] . flange [ 0 ] = 11 ; _dline -> compilerData
-> block [ 31 ] . transducer = _table -> DriveTransducer_table + 5 ; _dline
-> compilerData -> block [ 31 ] . transducer [ 0 ] . numSignals = 2 ; _dline
-> compilerData -> block [ 31 ] . transducer [ 0 ] . positionFlag = ( char *
) ( _table -> UINT8_table + 5099 ) ; strcpy ( _dline -> compilerData -> block
[ 31 ] . transducer [ 0 ] . positionFlag , "Undefined" ) ; _dline ->
compilerData -> block [ 31 ] . transducer [ 0 ] . velocityFlag = ( char * ) (
_table -> UINT8_table + 5109 ) ; strcpy ( _dline -> compilerData -> block [
31 ] . transducer [ 0 ] . velocityFlag , "Undefined" ) ; _dline ->
compilerData -> block [ 31 ] . transducer [ 0 ] . accelerationFlag = ( char *
) ( _table -> UINT8_table + 5119 ) ; strcpy ( _dline -> compilerData -> block
[ 31 ] . transducer [ 0 ] . accelerationFlag , "Undefined" ) ; _dline ->
compilerData -> block [ 31 ] . transducer [ 0 ] . signal = _table ->
DriveSignal_table + 9 ; _dline -> compilerData -> block [ 31 ] . transducer [
0 ] . signal [ 0 ] . type = DRIVEVELOCITY ; _dline -> compilerData -> block [
31 ] . transducer [ 0 ] . signal [ 0 ] . flag = ( char * ) ( _table ->
UINT8_table + 5129 ) ; strcpy ( _dline -> compilerData -> block [ 31 ] .
transducer [ 0 ] . signal [ 0 ] . flag , "drive_ef55c1e7Velocity" ) ; _dline
-> compilerData -> block [ 31 ] . transducer [ 0 ] . signal [ 1 ] . type =
DRIVEACCELERATION ; _dline -> compilerData -> block [ 31 ] . transducer [ 0 ]
. signal [ 1 ] . flag = ( char * ) ( _table -> UINT8_table + 5152 ) ; strcpy
( _dline -> compilerData -> block [ 31 ] . transducer [ 0 ] . signal [ 1 ] .
flag , "drive_ef55c1e7Acceleration" ) ; _dline -> compilerData -> block [ 32
] . numFlanges = 1 ; _dline -> compilerData -> block [ 32 ] . numParameters =
2 ; _dline -> compilerData -> block [ 32 ] . parameter = _table ->
DriveParameter_table + 23 ; _dline -> compilerData -> block [ 32 ] .
parameter [ 0 ] . type = DRIVERTP_INERTIA ; _dline -> compilerData -> block [
32 ] . parameter [ 0 ] . flag = ( char * ) ( _table -> UINT8_table + 5179 ) ;
strcpy ( _dline -> compilerData -> block [ 32 ] . parameter [ 0 ] . flag ,
"drive_85dd3f67Inertia" ) ; _dline -> compilerData -> block [ 32 ] .
parameter [ 1 ] . type = DRIVERTP_INITIALCONDITION ; _dline -> compilerData
-> block [ 32 ] . parameter [ 1 ] . flag = ( char * ) ( _table -> UINT8_table
+ 5201 ) ; strcpy ( _dline -> compilerData -> block [ 32 ] . parameter [ 1 ]
. flag , "drive_85dd3f67InitialCondition" ) ; _dline -> compilerData -> block
[ 32 ] . numInertia = 1 ; _dline -> compilerData -> block [ 32 ] . name = (
char * ) ( _table -> UINT8_table + 5232 ) ; strcpy ( _dline -> compilerData
-> block [ 32 ] . name , "hybrid_powertrain_P5/Transmission/Inertia" ) ;
_dline -> compilerData -> block [ 32 ] . visibleName = ( char * ) ( _table ->
UINT8_table + 5274 ) ; strcpy ( _dline -> compilerData -> block [ 32 ] .
visibleName , "hybrid_powertrain_P5/Transmission/Inertia" ) ; _dline ->
compilerData -> block [ 32 ] . type = DRIVEINERTIA ; _dline -> compilerData
-> block [ 32 ] . flange = _table -> INT32_table + 53 ; _dline ->
compilerData -> block [ 32 ] . inertia = _table -> DriveInertia_table + 5 ;
_dline -> compilerData -> block [ 32 ] . inertia [ 0 ] . inertia = 10.0 ;
_dline -> compilerData -> block [ 33 ] . numFlanges = 1 ; _dline ->
compilerData -> block [ 33 ] . numTransducer = 1 ; _dline -> compilerData ->
block [ 33 ] . name = ( char * ) ( _table -> UINT8_table + 5316 ) ; strcpy (
_dline -> compilerData -> block [ 33 ] . name ,
"hybrid_powertrain_P5/Gasoline Engine/Motion Sensor/Transducer" ) ; _dline ->
compilerData -> block [ 33 ] . visibleName = ( char * ) ( _table ->
UINT8_table + 5378 ) ; strcpy ( _dline -> compilerData -> block [ 33 ] .
visibleName , "hybrid_powertrain_P5/Gasoline Engine" ) ; _dline ->
compilerData -> block [ 33 ] . type = DRIVETRANSDUCER ; _dline ->
compilerData -> block [ 33 ] . flange = _table -> INT32_table + 54 ; _dline
-> compilerData -> block [ 33 ] . transducer = _table ->
DriveTransducer_table + 6 ; _dline -> compilerData -> block [ 33 ] .
transducer [ 0 ] . numSignals = 2 ; _dline -> compilerData -> block [ 33 ] .
transducer [ 0 ] . positionFlag = ( char * ) ( _table -> UINT8_table + 5415 )
; strcpy ( _dline -> compilerData -> block [ 33 ] . transducer [ 0 ] .
positionFlag , "Undefined" ) ; _dline -> compilerData -> block [ 33 ] .
transducer [ 0 ] . velocityFlag = ( char * ) ( _table -> UINT8_table + 5425 )
; strcpy ( _dline -> compilerData -> block [ 33 ] . transducer [ 0 ] .
velocityFlag , "Undefined" ) ; _dline -> compilerData -> block [ 33 ] .
transducer [ 0 ] . accelerationFlag = ( char * ) ( _table -> UINT8_table +
5435 ) ; strcpy ( _dline -> compilerData -> block [ 33 ] . transducer [ 0 ] .
accelerationFlag , "Undefined" ) ; _dline -> compilerData -> block [ 33 ] .
transducer [ 0 ] . signal = _table -> DriveSignal_table + 11 ; _dline ->
compilerData -> block [ 33 ] . transducer [ 0 ] . signal [ 0 ] . type =
DRIVEVELOCITY ; _dline -> compilerData -> block [ 33 ] . transducer [ 0 ] .
signal [ 0 ] . flag = ( char * ) ( _table -> UINT8_table + 5445 ) ; strcpy (
_dline -> compilerData -> block [ 33 ] . transducer [ 0 ] . signal [ 0 ] .
flag , "drive_8c8fa53Velocity" ) ; _dline -> compilerData -> block [ 33 ] .
transducer [ 0 ] . signal [ 1 ] . type = DRIVEACCELERATION ; _dline ->
compilerData -> block [ 33 ] . transducer [ 0 ] . signal [ 1 ] . flag = (
char * ) ( _table -> UINT8_table + 5467 ) ; strcpy ( _dline -> compilerData
-> block [ 33 ] . transducer [ 0 ] . signal [ 1 ] . flag ,
"drive_8c8fa53Acceleration" ) ; _dline -> compilerData -> block [ 34 ] .
numFlanges = 1 ; _dline -> compilerData -> block [ 34 ] . numTransducer = 1 ;
_dline -> compilerData -> block [ 34 ] . name = ( char * ) ( _table ->
UINT8_table + 5493 ) ; strcpy ( _dline -> compilerData -> block [ 34 ] . name
, "hybrid_powertrain_P5/Gasoline Engine/Torque Actuator/Transducer" ) ;
_dline -> compilerData -> block [ 34 ] . visibleName = ( char * ) ( _table ->
UINT8_table + 5557 ) ; strcpy ( _dline -> compilerData -> block [ 34 ] .
visibleName , "hybrid_powertrain_P5/Gasoline Engine" ) ; _dline ->
compilerData -> block [ 34 ] . type = DRIVETRANSDUCER ; _dline ->
compilerData -> block [ 34 ] . flange = _table -> INT32_table + 55 ; _dline
-> compilerData -> block [ 34 ] . transducer = _table ->
DriveTransducer_table + 7 ; _dline -> compilerData -> block [ 34 ] .
transducer [ 0 ] . numSignals = 1 ; _dline -> compilerData -> block [ 34 ] .
transducer [ 0 ] . positionFlag = ( char * ) ( _table -> UINT8_table + 5594 )
; strcpy ( _dline -> compilerData -> block [ 34 ] . transducer [ 0 ] .
positionFlag , "Undefined" ) ; _dline -> compilerData -> block [ 34 ] .
transducer [ 0 ] . velocityFlag = ( char * ) ( _table -> UINT8_table + 5604 )
; strcpy ( _dline -> compilerData -> block [ 34 ] . transducer [ 0 ] .
velocityFlag , "Undefined" ) ; _dline -> compilerData -> block [ 34 ] .
transducer [ 0 ] . accelerationFlag = ( char * ) ( _table -> UINT8_table +
5614 ) ; strcpy ( _dline -> compilerData -> block [ 34 ] . transducer [ 0 ] .
accelerationFlag , "Undefined" ) ; _dline -> compilerData -> block [ 34 ] .
transducer [ 0 ] . signal = _table -> DriveSignal_table + 13 ; _dline ->
compilerData -> block [ 34 ] . transducer [ 0 ] . signal [ 0 ] . type =
DRIVEEXTERNALTORQUE ; _dline -> compilerData -> block [ 34 ] . transducer [ 0
] . signal [ 0 ] . flag = ( char * ) ( _table -> UINT8_table + 5624 ) ;
strcpy ( _dline -> compilerData -> block [ 34 ] . transducer [ 0 ] . signal [
0 ] . flag , "drive_31257aa6Tor" ) ; _dline -> compilerData -> ioSizes .
numModes = 4 ; _dline -> compilerData -> ioSizes . numZeroCrossings = 16 ;
_dline -> compilerData -> ioSizes . numDynamicInputs = 14 ; _dline ->
compilerData -> ioSizes . numDynamicOutputs = 6 ; _dline -> compilerData ->
ioSizes . numKinematicOutputs = 14 ; _dline -> compilerData -> ioSizes .
numRtParameters = 25 ; _dline -> compilerData -> name = ( char * ) ( _table
-> UINT8_table + 5642 ) ; strcpy ( _dline -> compilerData -> name ,
"hybrid_powertrain_P5/Transmission/Driveline\\\\nEnvironment" ) ; _dline ->
compilerData -> mdlHandle = 2.0001220703125 ; return _dline ; }
