#include "__cf_hybrid_powertrain_P5.h"
#include "drive_std.h"
#ifdef __cplusplus
extern "C" {
#endif
#ifndef DRIVE_HYBRID_POWERTRAIN_P5_1_H
#define DRIVE_HYBRID_POWERTRAIN_P5_1_H 1
#ifndef struct_drive_hybrid_powertrain_P5_1_data_table_tag
#define struct_drive_hybrid_powertrain_P5_1_data_table_tag
typedef struct drive_hybrid_powertrain_P5_1_data_table_tag { DriveLine _dline
; DriveSignal DriveSignal_table [ 14 ] ; DriveTransducer
DriveTransducer_table [ 8 ] ; DriveInertia DriveInertia_table [ 6 ] ;
DrivePlanetPlanet DrivePlanetPlanet_table [ 4 ] ; DriveWeld DriveWeld_table [
3 ] ; DriveSimpleGear DriveSimpleGear_table [ 9 ] ; DriveParameter
DriveParameter_table [ 25 ] ; DriveClutch DriveClutch_table [ 4 ] ;
DriveSolver DriveSolver_table [ 1 ] ; uint8_T UINT8_table [ 5698 ] ;
DriveBlock DriveBlock_table [ 35 ] ; int32_T INT32_table [ 56 ] ;
DriveCompilerData DriveCompilerData_table [ 1 ] ; }
drive_hybrid_powertrain_P5_1_data_table ;
#else
typedef struct drive_hybrid_powertrain_P5_1_data_table_tag
drive_hybrid_powertrain_P5_1_data_table ;
#endif
extern DriveLine * _drive_hybrid_powertrain_P5_1_drive_line ; extern
DriveLine * drive_hybrid_powertrain_P5_1_drive_line (
drive_hybrid_powertrain_P5_1_data_table * _table ) ;
#endif
#ifdef __cplusplus
}
#endif
