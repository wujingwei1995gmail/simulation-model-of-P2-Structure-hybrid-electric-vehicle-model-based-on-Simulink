#include "__cf_hybrid_powertrain_P5.h"
#include <math.h>
#include "hybrid_powertrain_P5_acc.h"
#include "hybrid_powertrain_P5_acc_private.h"
#include <stdio.h>
#include "slexec_vm_simstruct_bridge.h"
#include "slexec_vm_zc_functions.h"
#include "simstruc.h"
#include "fixedpoint.h"
#define CodeFormat S-Function
#define AccDefine1 Accelerator_S-Function
#include "simtarget/slAccSfcnBridge.h"
static void mdlOutputs ( SimStruct * S , int_T tid ) { boolean_T resetIntg ;
ZCEventType zcEvent ; boolean_T dypv5w0rj2 ; boolean_T n05zysbb1f ; real_T
pg0c4gu1ph ; real_T ratio ; uint32_T numCycles ; uint8_T ipkesgppwf ; real_T
pit4rybkem ; real_T opypanqluz ; d0zkhgwawu * _rtB ; inli0fq1nl * _rtP ;
lbhaipo2el * _rtX ; jdannnw0pz * _rtZCE ; a502cmnw43 * _rtDW ; _rtDW = ( (
a502cmnw43 * ) ssGetRootDWork ( S ) ) ; _rtZCE = ( ( jdannnw0pz * )
_ssGetPrevZCSigState ( S ) ) ; _rtX = ( ( lbhaipo2el * ) ssGetContStates ( S
) ) ; _rtP = ( ( inli0fq1nl * ) ssGetDefaultParam ( S ) ) ; _rtB = ( (
d0zkhgwawu * ) _ssGetBlockIO ( S ) ) ; ssCallAccelRunBlock ( S , 12 , 0 ,
SS_CALL_MDL_OUTPUTS ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> nvnkw0twvc = ( _rtB -> oxbt0trr3a [ 0 ]
> _rtB -> k3k5vqljtl ) ; } dypv5w0rj2 = _rtDW -> nvnkw0twvc ; } if (
ssIsMajorTimeStep ( S ) ) { if ( _rtX -> ma3glufdgs >= _rtP -> P_23 ) { _rtDW
-> lewi3ks1mz = true ; } else { if ( _rtX -> ma3glufdgs <= _rtP -> P_24 ) {
_rtDW -> lewi3ks1mz = false ; } } if ( _rtX -> co5ubxh3w3 >= _rtP -> P_28 ) {
_rtX -> co5ubxh3w3 = _rtP -> P_28 ; } else { if ( _rtX -> co5ubxh3w3 <= _rtP
-> P_29 ) { _rtX -> co5ubxh3w3 = _rtP -> P_29 ; } } } _rtB -> kobhyrri1w =
_rtX -> co5ubxh3w3 ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> dwg20kttxu = ( _rtB -> kobhyrri1w > _rtB
-> glcoukqg5d ) ; } n05zysbb1f = _rtDW -> dwg20kttxu ; if ( _rtDW ->
lewi3ks1mz ) { pit4rybkem = _rtP -> P_25 ; } else { pit4rybkem = _rtP -> P_26
; } pit4rybkem += ( real_T ) _rtDW -> dwg20kttxu ; if ( pit4rybkem >= _rtP ->
P_31 ) { _rtDW -> ljeuuxjryc = true ; } else { if ( pit4rybkem <= _rtP ->
P_32 ) { _rtDW -> ljeuuxjryc = false ; } } if ( dypv5w0rj2 ) { if ( _rtDW ->
ljeuuxjryc ) { pit4rybkem = _rtP -> P_33 ; } else { pit4rybkem = _rtP -> P_34
; } _rtB -> nyykdh4onm = ( ( pit4rybkem != 0.0 ) || _rtDW -> dwg20kttxu ) ; }
else { _rtB -> nyykdh4onm = _rtB -> p3its42cvd ; } if ( _rtDW -> pobimgru15 )
{ _rtDW -> pobimgru15 = false ; _rtB -> n3zdq0wmp3 = _rtP -> P_36 ; } else {
_rtB -> n3zdq0wmp3 = _rtB -> bhfrfh0x2b ; } } if ( ssIsMajorTimeStep ( S ) )
{ resetIntg = false ; zcEvent = rt_ZCFcn ( RISING_ZERO_CROSSING , & _rtZCE ->
jo0e41jv05 , ( _rtB -> nyykdh4onm ) ) ; if ( ( zcEvent != NO_ZCEVENT ) || (
_rtDW -> p54ywcoivr != 0 ) ) { resetIntg = true ; _rtX -> ma3glufdgs = _rtB
-> n3zdq0wmp3 ; } if ( resetIntg ) { ssSetSolverNeedsReset ( S ) ;
ssSetBlkStateChange ( S ) ; } } _rtB -> dgn1zot3ia = _rtX -> ma3glufdgs ; if
( ssIsMajorTimeStep ( S ) ) { resetIntg = false ; zcEvent = rt_ZCFcn (
FALLING_ZERO_CROSSING , & _rtZCE -> fepub5kpxh , ( _rtB -> nyykdh4onm ) ) ;
if ( zcEvent != NO_ZCEVENT ) { resetIntg = true ; _rtX -> mbi5wbgodl = _rtP
-> P_37 ; } if ( resetIntg ) { ssSetSolverNeedsReset ( S ) ; } if ( _rtX ->
mbi5wbgodl >= _rtP -> P_38 ) { _rtX -> mbi5wbgodl = _rtP -> P_38 ; } else {
if ( _rtX -> mbi5wbgodl <= _rtP -> P_39 ) { _rtX -> mbi5wbgodl = _rtP -> P_39
; } } } _rtB -> ixbocf0kdl = _rtX -> mbi5wbgodl ; if ( _rtB -> nyykdh4onm >=
_rtP -> P_40 ) { _rtB -> b1qykfn1xt = _rtB -> dgn1zot3ia ; } else { _rtB ->
fnelsjy5g5 = _rtB -> dgn1zot3ia * rt_Lookup ( _rtP -> P_6 , 4 , _rtB ->
ixbocf0kdl , _rtP -> P_7 ) ; _rtB -> b1qykfn1xt = _rtB -> fnelsjy5g5 ; } if (
ssIsMajorTimeStep ( S ) ) { if ( _rtX -> abcadcsyqr >= _rtP -> P_41 ) { _rtDW
-> ho4raeuelg = true ; } else { if ( _rtX -> abcadcsyqr <= _rtP -> P_42 ) {
_rtDW -> ho4raeuelg = false ; } } if ( _rtX -> lgagow5yei >= _rtP -> P_46 ) {
_rtX -> lgagow5yei = _rtP -> P_46 ; } else { if ( _rtX -> lgagow5yei <= _rtP
-> P_47 ) { _rtX -> lgagow5yei = _rtP -> P_47 ; } } } _rtB -> gc0ces3pny =
_rtX -> lgagow5yei ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> mninf3v1di = ( _rtB -> gc0ces3pny > _rtB
-> ceguswtlh1 ) ; } n05zysbb1f = _rtDW -> mninf3v1di ; pg0c4gu1ph = _rtDW ->
mninf3v1di ; if ( _rtDW -> ho4raeuelg ) { pit4rybkem = _rtP -> P_43 ; } else
{ pit4rybkem = _rtP -> P_44 ; } pit4rybkem += ( real_T ) _rtDW -> mninf3v1di
; if ( pit4rybkem >= _rtP -> P_49 ) { _rtDW -> ovaeihxq1z = true ; } else {
if ( pit4rybkem <= _rtP -> P_50 ) { _rtDW -> ovaeihxq1z = false ; } } if (
_rtDW -> ovaeihxq1z ) { opypanqluz = _rtP -> P_51 ; } else { opypanqluz =
_rtP -> P_52 ; } } if ( ssIsSampleHit ( S , 2 , 0 ) ) { pit4rybkem =
ssGetTaskTime ( S , 2 ) ; if ( ssGetTNextWasAdjusted ( S , 2 ) ) { _rtDW ->
hmenkbqdul = _ssGetVarNextHitTime ( S , 0 ) ; } if ( _rtDW -> ewvzwysh0q != 0
) { _rtDW -> ewvzwysh0q = 0 ; if ( pit4rybkem >= _rtP -> P_56 ) { ratio = (
pit4rybkem - _rtP -> P_56 ) / _rtP -> P_54 ; numCycles = ( uint32_T )
muDoubleScalarFloor ( ratio ) ; if ( muDoubleScalarAbs ( ( real_T ) (
numCycles + 1U ) - ratio ) < DBL_EPSILON * ratio ) { numCycles ++ ; } _rtDW
-> eqdmsmu11f = numCycles ; ratio = ( ( real_T ) numCycles * _rtP -> P_54 +
_rtP -> P_56 ) + _rtP -> P_55 * _rtP -> P_54 / 100.0 ; if ( pit4rybkem <
ratio ) { _rtDW -> isnimkczge = 1 ; _rtDW -> hmenkbqdul = ratio ; } else {
_rtDW -> isnimkczge = 0 ; _rtDW -> hmenkbqdul = ( real_T ) ( numCycles + 1U )
* _rtP -> P_54 + _rtP -> P_56 ; } } else { _rtDW -> eqdmsmu11f = _rtP -> P_56
!= 0.0 ? - 1 : 0 ; _rtDW -> isnimkczge = 0 ; _rtDW -> hmenkbqdul = _rtP ->
P_56 ; } } else { if ( _rtDW -> hmenkbqdul <= pit4rybkem ) { if ( _rtDW ->
isnimkczge == 1 ) { _rtDW -> isnimkczge = 0 ; _rtDW -> hmenkbqdul = ( real_T
) ( _rtDW -> eqdmsmu11f + 1LL ) * _rtP -> P_54 + _rtP -> P_56 ; } else {
_rtDW -> eqdmsmu11f ++ ; _rtDW -> isnimkczge = 1 ; _rtDW -> hmenkbqdul = (
_rtP -> P_55 * _rtP -> P_54 * 0.01 + ( real_T ) _rtDW -> eqdmsmu11f * _rtP ->
P_54 ) + _rtP -> P_56 ; } } } _ssSetVarNextHitTime ( S , 0 , _rtDW ->
hmenkbqdul ) ; if ( _rtDW -> isnimkczge == 1 ) { _rtB -> gor00zeg0p = _rtP ->
P_53 ; } else { _rtB -> gor00zeg0p = 0.0 ; } } _rtB -> hhze4jyfb3 = _rtB ->
oxbt0trr3a [ 1 ] * _rtB -> gor00zeg0p ; if ( ssIsSampleHit ( S , 1 , 0 ) ) {
if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> cpr52i3ku4 = ( _rtB -> hhze4jyfb3 >
_rtB -> gqvqxivkjj ) ; } n05zysbb1f = _rtDW -> cpr52i3ku4 ; if ( _rtDW ->
cpr52i3ku4 ) { _rtB -> gwc5uhen0e = ( ( opypanqluz != 0.0 ) || ( pg0c4gu1ph
!= 0.0 ) ) ; } else { _rtB -> gwc5uhen0e = _rtB -> jxqolpe13z ; } if ( _rtDW
-> hmvptpy4fe ) { _rtDW -> hmvptpy4fe = false ; _rtB -> oadpnkwogk = _rtP ->
P_60 ; } else { _rtB -> oadpnkwogk = _rtB -> bq2p0tfbqz ; } } if (
ssIsMajorTimeStep ( S ) ) { resetIntg = false ; zcEvent = rt_ZCFcn (
RISING_ZERO_CROSSING , & _rtZCE -> fklxzrbqc1 , ( _rtB -> gwc5uhen0e ) ) ; if
( ( zcEvent != NO_ZCEVENT ) || ( _rtDW -> cw4vcfdnns != 0 ) ) { resetIntg =
true ; _rtX -> abcadcsyqr = _rtB -> oadpnkwogk ; } if ( resetIntg ) {
ssSetSolverNeedsReset ( S ) ; ssSetBlkStateChange ( S ) ; } } _rtB ->
kvcaqm5tmx = _rtX -> abcadcsyqr ; if ( ssIsMajorTimeStep ( S ) ) { resetIntg
= false ; zcEvent = rt_ZCFcn ( FALLING_ZERO_CROSSING , & _rtZCE -> bhwoijscij
, ( _rtB -> gwc5uhen0e ) ) ; if ( zcEvent != NO_ZCEVENT ) { resetIntg = true
; _rtX -> ot1icumkg5 = _rtP -> P_61 ; } if ( resetIntg ) {
ssSetSolverNeedsReset ( S ) ; } if ( _rtX -> ot1icumkg5 >= _rtP -> P_62 ) {
_rtX -> ot1icumkg5 = _rtP -> P_62 ; } else { if ( _rtX -> ot1icumkg5 <= _rtP
-> P_63 ) { _rtX -> ot1icumkg5 = _rtP -> P_63 ; } } } _rtB -> mjqgyevsmb =
_rtX -> ot1icumkg5 ; if ( _rtB -> gwc5uhen0e >= _rtP -> P_64 ) { _rtB ->
imbmaebgbs = _rtB -> kvcaqm5tmx ; } else { _rtB -> nd5j1bcc4h = _rtB ->
kvcaqm5tmx * rt_Lookup ( _rtP -> P_10 , 4 , _rtB -> mjqgyevsmb , _rtP -> P_11
) ; _rtB -> imbmaebgbs = _rtB -> nd5j1bcc4h ; } _rtB -> mdbif4xnjc [ 0 ] =
_rtB -> gpbdctsrm1 ; _rtB -> mdbif4xnjc [ 1 ] = _rtB -> ke031wwb25 ; _rtB ->
mdbif4xnjc [ 2 ] = _rtB -> fjd5vjfs2b ; _rtB -> mdbif4xnjc [ 3 ] = _rtB ->
c45tydnt5f ; _rtB -> mdbif4xnjc [ 4 ] = _rtB -> f5oj515tvf ; _rtB ->
mdbif4xnjc [ 5 ] = _rtB -> gtc30z5nru ; _rtB -> mdbif4xnjc [ 6 ] = _rtB ->
l02aoh4vmx ; _rtB -> mdbif4xnjc [ 7 ] = _rtB -> dahuht42nw ; _rtB ->
mdbif4xnjc [ 8 ] = _rtB -> cwixgqpm0a ; _rtB -> mdbif4xnjc [ 9 ] = _rtB ->
b4i4wrrkuo ; _rtB -> mdbif4xnjc [ 10 ] = _rtB -> i3eowuclfr ; _rtB ->
mdbif4xnjc [ 11 ] = _rtB -> eaofgv2qh2 ; _rtB -> mdbif4xnjc [ 12 ] = _rtB ->
kcrerj13yf ; _rtB -> mdbif4xnjc [ 13 ] = _rtB -> eyugbm4xom ; _rtB ->
mdbif4xnjc [ 14 ] = _rtB -> leso1ekrxv ; _rtB -> mdbif4xnjc [ 15 ] = _rtB ->
ghgmuyxgtc ; _rtB -> mdbif4xnjc [ 16 ] = _rtB -> h51nzyvoy4 ; _rtB ->
mdbif4xnjc [ 17 ] = _rtB -> mrhwsddjxw ; _rtB -> mdbif4xnjc [ 18 ] = _rtB ->
c1lav4hnkn ; _rtB -> mdbif4xnjc [ 19 ] = _rtB -> dczisasage ; _rtB ->
mdbif4xnjc [ 20 ] = _rtB -> mxxzbgpi4s ; _rtB -> mdbif4xnjc [ 21 ] = _rtB ->
fmqljw4tbu ; _rtB -> mdbif4xnjc [ 22 ] = _rtB -> hpidnvqo30 ; _rtB ->
mdbif4xnjc [ 23 ] = _rtB -> japdnbcdcj ; _rtB -> mdbif4xnjc [ 24 ] = _rtB ->
fqkeh503oq ; _rtB -> cffpsw0rzm = 0 ; _rtB -> eb2aix04zk = _rtB -> gvoomtptlj
+ _rtB -> cffpsw0rzm ; if ( ( _rtDW -> dmlgpabp13 == ( rtMinusInf ) ) || (
_rtDW -> dmlgpabp13 == ssGetTaskTime ( S , 0 ) ) ) { _rtDW -> dmlgpabp13 =
ssGetTaskTime ( S , 0 ) ; pg0c4gu1ph = _rtP -> P_92 ; } else { pg0c4gu1ph =
_rtB -> eb2aix04zk ; } _rtB -> ldteezdf3g = _rtP -> P_93 * pg0c4gu1ph ;
ssCallAccelRunBlock ( S , 12 , 72 , SS_CALL_MDL_OUTPUTS ) ;
ssCallAccelRunBlock ( S , 12 , 73 , SS_CALL_MDL_OUTPUTS ) ; _rtB ->
a25naqbzdy = _rtP -> P_94 * _rtB -> avpfijxdss [ 6 ] ; _rtB -> ndb5ndewd4 =
_rtP -> P_95 * _rtB -> a25naqbzdy ; ssCallAccelRunBlock ( S , 12 , 78 ,
SS_CALL_MDL_OUTPUTS ) ; if ( ssIsSampleHit ( S , 1 , 0 ) ) { if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> hvk2q5h42l = ( _rtB -> mea2ufuujr [ 3 ]
> _rtB -> d0ecqku03v ) ; } _rtB -> i0mziyc3ux = ( _rtDW -> hvk2q5h42l &&
dypv5w0rj2 ) ; } _rtB -> g4cnccoqkb = _rtB -> i0mziyc3ux - _rtB -> kobhyrri1w
; _rtB -> lni02wtqx0 = _rtP -> P_109 * _rtB -> g4cnccoqkb ; if ( _rtB ->
nyykdh4onm >= _rtP -> P_112 ) { _rtB -> jasmb5tzyk = _rtP -> P_4 * _rtB ->
dgn1zot3ia ; _rtB -> jf5khtnu3w = ( _rtB -> mea2ufuujr [ 3 ] - _rtB ->
jasmb5tzyk ) - _rtB -> otzzzjlfwb ; _rtB -> drcatqd2yf = _rtP -> P_5 * _rtB
-> jf5khtnu3w ; _rtB -> p1ie0qb2py = _rtB -> drcatqd2yf ; } else { _rtB ->
p1ie0qb2py = _rtB -> nvgsbb4ton ; } if ( ssIsSampleHit ( S , 1 , 0 ) ) { if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> dvhorkzgao = ( _rtB -> mea2ufuujr [ 4 ]
> _rtB -> ibqizvhqon ) ; } _rtB -> phkow4yd4b = ( _rtDW -> dvhorkzgao &&
n05zysbb1f ) ; } _rtB -> mlpegorz1k = _rtB -> phkow4yd4b - _rtB -> gc0ces3pny
; _rtB -> nrtdj4obb2 = _rtP -> P_115 * _rtB -> mlpegorz1k ; if ( _rtB ->
gwc5uhen0e >= _rtP -> P_118 ) { _rtB -> miee1ahi03 = _rtP -> P_8 * _rtB ->
kvcaqm5tmx ; _rtB -> awyww2rqvx = ( _rtB -> mea2ufuujr [ 4 ] - _rtB ->
miee1ahi03 ) - _rtB -> haixehcmnm ; _rtB -> fd5h3psjmp = _rtP -> P_9 * _rtB
-> awyww2rqvx ; _rtB -> pvhvrsroou = _rtB -> fd5h3psjmp ; } else { _rtB ->
pvhvrsroou = _rtB -> ik35n45sbt ; } if ( ssIsMajorTimeStep ( S ) ) { _rtDW ->
fdeeygjlko = ( _rtB -> jktokfxdjj [ 1 ] >= _rtP -> P_121 ) ; } if ( _rtDW ->
fdeeygjlko ) { _rtB -> jdghtvuipb = _rtP -> P_2 * _rtB -> mea2ufuujr [ 1 ] ;
_rtB -> jfh3lr3zau = _rtB -> jdghtvuipb ; } else { _rtB -> jfh3lr3zau = _rtB
-> hunlrwitx0 ; } if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> o3dtsgph5d = _rtB
-> jfh3lr3zau >= _rtP -> P_122 ? 1 : _rtB -> jfh3lr3zau > _rtP -> P_123 ? 0 :
- 1 ; _rtDW -> owecgug4s2 = ( _rtB -> jktokfxdjj [ 2 ] >= _rtP -> P_125 ) ; }
if ( _rtDW -> owecgug4s2 ) { _rtB -> c1y005tndo = _rtP -> P_3 * _rtB ->
mea2ufuujr [ 2 ] ; _rtB -> nye4t3guib = _rtB -> c1y005tndo ; } else { _rtB ->
nye4t3guib = _rtB -> akbzlg0gpw ; } if ( ssIsMajorTimeStep ( S ) ) { _rtDW ->
ok0xhshmnd = _rtB -> nye4t3guib >= _rtP -> P_126 ? 1 : _rtB -> nye4t3guib >
_rtP -> P_127 ? 0 : - 1 ; _rtDW -> o1iltqmmdo = ( _rtB -> jktokfxdjj [ 0 ] >=
_rtP -> P_129 ) ; } if ( _rtDW -> o1iltqmmdo ) { _rtB -> jsgafk5xp5 = _rtP ->
P_12 * _rtB -> mea2ufuujr [ 0 ] ; } _rtB -> mlnkiltx2b = _rtP -> P_130 * _rtB
-> mea2ufuujr [ 6 ] ; _rtB -> pair4ggt4i = _rtP -> P_131 * _rtB -> mlnkiltx2b
; _rtB -> bloyrzaxhh = _rtP -> P_132 * _rtB -> mea2ufuujr [ 5 ] ; _rtB ->
jlubof3i50 = _rtX -> l4dwujw3ky ; _rtB -> cyxsvrsorb = _rtP -> P_134 * _rtB
-> jlubof3i50 ; if ( ssIsSampleHit ( S , 1 , 0 ) && ssIsMajorTimeStep ( S ) )
{ if ( _rtB -> oxbt0trr3a [ 1 ] > 0.0 ) { if ( ! _rtDW -> mfcrnzu51s ) { ( (
ou3tya32xz * ) ssGetContStateDisabled ( S ) ) -> ladquobflf = 0 ; if (
ssGetTaskTime ( S , 1 ) != ssGetTStart ( S ) ) { ssSetSolverNeedsReset ( S )
; } _rtDW -> mfcrnzu51s = true ; } } else { if ( _rtDW -> mfcrnzu51s ) {
ssSetSolverNeedsReset ( S ) ; ( ( ou3tya32xz * ) ssGetContStateDisabled ( S )
) -> ladquobflf = 1 ; _rtDW -> mfcrnzu51s = false ; } } } if ( _rtDW ->
mfcrnzu51s ) { _rtB -> omk0qn4hpv = _rtX -> ladquobflf ; _rtB -> i43alvyekm =
_rtB -> e3fa3himqr * _rtB -> omk0qn4hpv ; _rtB -> ioivuu43kl = _rtP -> P_1 *
_rtB -> i43alvyekm ; if ( ssIsMajorTimeStep ( S ) ) { srUpdateBC ( _rtDW ->
gop25k0t2l ) ; } } if ( ssIsSampleHit ( S , 1 , 0 ) ) { _rtB -> bg3kaqmiys =
_rtDW -> pekgcqftt5 ; } if ( _rtB -> ezowm5istg != 0.0 ) { _rtB -> piazyy52ly
= _rtB -> paoaozuici ; } else { pg0c4gu1ph = _rtP -> P_16 * _rtB ->
avpfijxdss [ 7 ] ; opypanqluz = pg0c4gu1ph * pg0c4gu1ph * _rtP -> P_17 ;
pg0c4gu1ph = _rtP -> P_18 * _rtB -> avpfijxdss [ 12 ] ; _rtB -> piazyy52ly =
muDoubleScalarMax ( pg0c4gu1ph * pg0c4gu1ph * _rtP -> P_19 + opypanqluz ,
_rtB -> bg3kaqmiys ) ; } _rtB -> l4zzfprpaf = _rtB -> ioivuu43kl / ( _rtB ->
piazyy52ly + _rtB -> o0b4ndx3oy ) ; ssCallAccelRunBlock ( S , 12 , 164 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> c3o41hirka = _rtP -> P_140 * _rtB ->
avpfijxdss [ 0 ] ; _rtB -> cdh0xotdk1 = muDoubleScalarAbs ( _rtB ->
c3o41hirka ) ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> dhiac513xj = _rtB ->
oxbt0trr3a [ 0 ] >= _rtP -> P_141 ? 1 : _rtB -> oxbt0trr3a [ 0 ] > _rtP ->
P_142 ? 0 : - 1 ; } _rtB -> kig5rrlids = _rtDW -> dhiac513xj == 1 ? _rtP ->
P_141 : _rtDW -> dhiac513xj == - 1 ? _rtP -> P_142 : _rtB -> oxbt0trr3a [ 0 ]
; if ( ssIsMajorTimeStep ( S ) ) { if ( _rtB -> kig5rrlids > _rtP -> P_144 )
{ _rtDW -> kmdcusof2v = 1 ; } else if ( _rtB -> kig5rrlids >= _rtP -> P_143 )
{ _rtDW -> kmdcusof2v = 0 ; } else { _rtDW -> kmdcusof2v = - 1 ; } } if (
_rtDW -> kmdcusof2v == 1 ) { _rtB -> jl010lq1f3 = _rtB -> kig5rrlids - _rtP
-> P_144 ; } else if ( _rtDW -> kmdcusof2v == - 1 ) { _rtB -> jl010lq1f3 =
_rtB -> kig5rrlids - _rtP -> P_143 ; } else { _rtB -> jl010lq1f3 = 0.0 ; }
_rtB -> ny1uobvgb3 = _rtP -> P_145 * _rtB -> jl010lq1f3 ; _rtB -> ak3thacfgs
= _rtB -> ny1uobvgb3 * rt_Lookup ( _rtP -> P_146 , 2 , _rtB -> cdh0xotdk1 ,
_rtP -> P_147 ) ; _rtB -> mi2o5chvxm = _rtB -> ak3thacfgs * _rtB ->
k2dmne4mno ; _rtB -> i4drpk5ht4 = _rtP -> P_149 * _rtB -> mi2o5chvxm ; _rtB
-> fr2hbsmfao = _rtB -> ak3thacfgs * _rtB -> k2dmne4mno ; _rtB -> bc2o1mbeld
= _rtP -> P_150 * _rtB -> avpfijxdss [ 8 ] ; _rtB -> phrvdyxuzp =
muDoubleScalarAbs ( _rtB -> bc2o1mbeld ) ; if ( ssIsMajorTimeStep ( S ) ) {
_rtDW -> povnrj5nez = _rtB -> oxbt0trr3a [ 1 ] >= _rtP -> P_151 ? 1 : _rtB ->
oxbt0trr3a [ 1 ] > _rtP -> P_152 ? 0 : - 1 ; } _rtB -> ojhqp2kimj = _rtDW ->
povnrj5nez == 1 ? _rtP -> P_151 : _rtDW -> povnrj5nez == - 1 ? _rtP -> P_152
: _rtB -> oxbt0trr3a [ 1 ] ; if ( ssIsMajorTimeStep ( S ) ) { if ( _rtB ->
ojhqp2kimj > _rtP -> P_154 ) { _rtDW -> ppkb5f3njb = 1 ; } else if ( _rtB ->
ojhqp2kimj >= _rtP -> P_153 ) { _rtDW -> ppkb5f3njb = 0 ; } else { _rtDW ->
ppkb5f3njb = - 1 ; } } if ( _rtDW -> ppkb5f3njb == 1 ) { _rtB -> ijxdhs0j2l =
_rtB -> ojhqp2kimj - _rtP -> P_154 ; } else if ( _rtDW -> ppkb5f3njb == - 1 )
{ _rtB -> ijxdhs0j2l = _rtB -> ojhqp2kimj - _rtP -> P_153 ; } else { _rtB ->
ijxdhs0j2l = 0.0 ; } _rtB -> keu2i33rym = _rtP -> P_155 * _rtB -> ijxdhs0j2l
; _rtB -> cz0ift2ina = _rtB -> keu2i33rym * rt_Lookup ( _rtP -> P_156 , 2 ,
_rtB -> phrvdyxuzp , _rtP -> P_157 ) ; _rtB -> b4ckgilcpm = _rtB ->
cz0ift2ina * _rtB -> klsljezotp ; _rtB -> l35q5ah34p = _rtP -> P_159 * _rtB
-> b4ckgilcpm ; _rtB -> losjyzzb5e = _rtB -> cz0ift2ina * _rtB -> klsljezotp
; _rtB -> nv3juwiv0q = _rtP -> P_160 * _rtB -> avpfijxdss [ 2 ] ; _rtB ->
e01kesqul1 = muDoubleScalarAbs ( _rtB -> nv3juwiv0q ) ; if (
ssIsMajorTimeStep ( S ) ) { _rtDW -> pv3jjmmhsg = _rtB -> oxbt0trr3a [ 1 ] >=
_rtP -> P_161 ? 1 : _rtB -> oxbt0trr3a [ 1 ] > _rtP -> P_162 ? 0 : - 1 ; }
_rtB -> c3eubtn4l4 = _rtDW -> pv3jjmmhsg == 1 ? _rtP -> P_161 : _rtDW ->
pv3jjmmhsg == - 1 ? _rtP -> P_162 : _rtB -> oxbt0trr3a [ 1 ] ; if (
ssIsMajorTimeStep ( S ) ) { if ( _rtB -> c3eubtn4l4 > _rtP -> P_164 ) { _rtDW
-> ic45asbzur = 1 ; } else if ( _rtB -> c3eubtn4l4 >= _rtP -> P_163 ) { _rtDW
-> ic45asbzur = 0 ; } else { _rtDW -> ic45asbzur = - 1 ; } } if ( _rtDW ->
ic45asbzur == 1 ) { _rtB -> ealuglnzhy = _rtB -> c3eubtn4l4 - _rtP -> P_164 ;
} else if ( _rtDW -> ic45asbzur == - 1 ) { _rtB -> ealuglnzhy = _rtB ->
c3eubtn4l4 - _rtP -> P_163 ; } else { _rtB -> ealuglnzhy = 0.0 ; } _rtB ->
orcxjpabjz = _rtP -> P_165 * _rtB -> ealuglnzhy ; _rtB -> iwgu3iv0kp = _rtB
-> orcxjpabjz * rt_Lookup ( _rtP -> P_166 , 2 , _rtB -> e01kesqul1 , _rtP ->
P_167 ) ; _rtB -> k1bo2xs3um = _rtB -> iwgu3iv0kp * _rtB -> cuhjqm1ucp ; _rtB
-> eiz5zfcews = _rtP -> P_169 * _rtB -> k1bo2xs3um ; _rtB -> acet1mfjkq =
_rtB -> iwgu3iv0kp * _rtB -> cuhjqm1ucp ; _rtB -> psdyfvtwdy = _rtP -> P_170
* _rtB -> avpfijxdss [ 4 ] ; _rtB -> luw15ec4bt = muDoubleScalarAbs ( _rtB ->
psdyfvtwdy ) ; _rtB -> n25aj5zh1t = _rtB -> oblffigztc - _rtB -> oxbt0trr3a [
2 ] ; if ( ssIsMajorTimeStep ( S ) ) { _rtDW -> br3b5dudjv = _rtB ->
n25aj5zh1t >= _rtP -> P_172 ? 1 : _rtB -> n25aj5zh1t > _rtP -> P_173 ? 0 : -
1 ; } _rtB -> g2lzaghajm = _rtDW -> br3b5dudjv == 1 ? _rtP -> P_172 : _rtDW
-> br3b5dudjv == - 1 ? _rtP -> P_173 : _rtB -> n25aj5zh1t ; if (
ssIsMajorTimeStep ( S ) ) { if ( _rtB -> g2lzaghajm > _rtP -> P_175 ) { _rtDW
-> iqny0hs2z4 = 1 ; } else if ( _rtB -> g2lzaghajm >= _rtP -> P_174 ) { _rtDW
-> iqny0hs2z4 = 0 ; } else { _rtDW -> iqny0hs2z4 = - 1 ; } } if ( _rtDW ->
iqny0hs2z4 == 1 ) { _rtB -> my4o1wzxls = _rtB -> g2lzaghajm - _rtP -> P_175 ;
} else if ( _rtDW -> iqny0hs2z4 == - 1 ) { _rtB -> my4o1wzxls = _rtB ->
g2lzaghajm - _rtP -> P_174 ; } else { _rtB -> my4o1wzxls = 0.0 ; } _rtB ->
ofe3bdzsnu = _rtP -> P_176 * _rtB -> my4o1wzxls ; _rtB -> iyg21km0vp = _rtB
-> ofe3bdzsnu * rt_Lookup ( _rtP -> P_177 , 2 , _rtB -> luw15ec4bt , _rtP ->
P_178 ) ; _rtB -> augpda41rt = _rtB -> iyg21km0vp * _rtB -> mn2oa4zbvl ; _rtB
-> cka4c1uz32 = _rtP -> P_180 * _rtB -> augpda41rt ; _rtB -> fvksuvd2bm =
_rtB -> iyg21km0vp * _rtB -> mn2oa4zbvl ; _rtB -> op4o3vof2h = _rtP -> P_182
* _rtB -> avpfijxdss [ 13 ] ; ipkesgppwf = ( uint8_T ) ( _rtB -> op4o3vof2h >
_rtB -> puinrhb2qm ) ; if ( ipkesgppwf >= _rtP -> P_190 ) { _rtB ->
jsk4ciqudh = _rtB -> ccfvhczdkk ; } else { _rtB -> eyfbm4c2t4 = _rtP -> P_13
* _rtB -> op4o3vof2h ; _rtB -> ovkvs3sana = rt_Lookup ( _rtP -> P_14 , 101 ,
_rtB -> eyfbm4c2t4 , _rtP -> P_15 ) * _rtB -> mefeco3esd ; _rtB -> jsk4ciqudh
= _rtB -> ovkvs3sana ; } _rtB -> bvfpzmhsjj [ 0 ] = _rtB -> ak3thacfgs ; _rtB
-> bvfpzmhsjj [ 1 ] = _rtB -> fr2hbsmfao ; _rtB -> bvfpzmhsjj [ 2 ] = _rtB ->
i4drpk5ht4 ; _rtB -> bvfpzmhsjj [ 3 ] = _rtB -> iwgu3iv0kp ; _rtB ->
bvfpzmhsjj [ 4 ] = _rtB -> acet1mfjkq ; _rtB -> bvfpzmhsjj [ 5 ] = _rtB ->
eiz5zfcews ; _rtB -> bvfpzmhsjj [ 6 ] = _rtB -> iyg21km0vp ; _rtB ->
bvfpzmhsjj [ 7 ] = _rtB -> fvksuvd2bm ; _rtB -> bvfpzmhsjj [ 8 ] = _rtB ->
cka4c1uz32 ; _rtB -> bvfpzmhsjj [ 9 ] = _rtB -> pair4ggt4i ; _rtB ->
bvfpzmhsjj [ 10 ] = _rtB -> cz0ift2ina ; _rtB -> bvfpzmhsjj [ 11 ] = _rtB ->
losjyzzb5e ; _rtB -> bvfpzmhsjj [ 12 ] = _rtB -> l35q5ah34p ; _rtB ->
bvfpzmhsjj [ 13 ] = _rtB -> jsk4ciqudh ; ssCallAccelRunBlock ( S , 12 , 291 ,
SS_CALL_MDL_OUTPUTS ) ; ssCallAccelRunBlock ( S , 12 , 292 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> djdy32us3n = ! ( ipkesgppwf != 0 ) ; if (
ssIsSampleHit ( S , 1 , 0 ) ) { ssCallAccelRunBlock ( S , 12 , 306 ,
SS_CALL_MDL_OUTPUTS ) ; } _rtB -> l4zzfprpaf = _rtP -> P_187 * _rtB ->
avpfijxdss [ 11 ] * _rtP -> P_188 ; ssCallAccelRunBlock ( S , 12 , 314 ,
SS_CALL_MDL_OUTPUTS ) ; _rtB -> l4zzfprpaf = _rtP -> P_189 * _rtB ->
avpfijxdss [ 10 ] ; ssCallAccelRunBlock ( S , 12 , 320 , SS_CALL_MDL_OUTPUTS
) ; UNUSED_PARAMETER ( tid ) ; } static void mdlOutputsTID3 ( SimStruct * S ,
int_T tid ) { d0zkhgwawu * _rtB ; inli0fq1nl * _rtP ; _rtP = ( ( inli0fq1nl *
) ssGetDefaultParam ( S ) ) ; _rtB = ( ( d0zkhgwawu * ) _ssGetBlockIO ( S ) )
; _rtB -> k3k5vqljtl = _rtP -> P_20 ; _rtB -> p3its42cvd = _rtP -> P_21 ;
_rtB -> lpcl44nchu [ 0 ] = _rtP -> P_22 [ 0 ] ; _rtB -> lpcl44nchu [ 1 ] =
_rtP -> P_22 [ 1 ] ; _rtB -> lpcl44nchu [ 2 ] = _rtP -> P_22 [ 2 ] ; _rtB ->
glcoukqg5d = _rtP -> P_30 ; _rtB -> bhfrfh0x2b = _rtP -> P_35 ; _rtB ->
ceguswtlh1 = _rtP -> P_48 ; _rtB -> gqvqxivkjj = _rtP -> P_57 ; _rtB ->
jxqolpe13z = _rtP -> P_58 ; _rtB -> bq2p0tfbqz = _rtP -> P_59 ; _rtB ->
ncl5zyxx31 = _rtP -> P_65 ; _rtB -> gpbdctsrm1 = _rtP -> P_66 ; _rtB ->
ke031wwb25 = _rtP -> P_67 ; _rtB -> fjd5vjfs2b = _rtP -> P_68 ; _rtB ->
c45tydnt5f = _rtP -> P_69 ; _rtB -> f5oj515tvf = _rtP -> P_70 ; _rtB ->
gtc30z5nru = _rtP -> P_71 ; _rtB -> l02aoh4vmx = _rtP -> P_72 ; _rtB ->
dahuht42nw = _rtP -> P_73 ; _rtB -> cwixgqpm0a = _rtP -> P_74 ; _rtB ->
b4i4wrrkuo = _rtP -> P_75 ; _rtB -> i3eowuclfr = _rtP -> P_76 ; _rtB ->
eaofgv2qh2 = _rtP -> P_77 ; _rtB -> kcrerj13yf = _rtP -> P_78 ; _rtB ->
eyugbm4xom = _rtP -> P_79 ; _rtB -> leso1ekrxv = _rtP -> P_80 ; _rtB ->
ghgmuyxgtc = _rtP -> P_81 ; _rtB -> h51nzyvoy4 = _rtP -> P_82 ; _rtB ->
mrhwsddjxw = _rtP -> P_83 ; _rtB -> c1lav4hnkn = _rtP -> P_84 ; _rtB ->
dczisasage = _rtP -> P_85 ; _rtB -> mxxzbgpi4s = _rtP -> P_86 ; _rtB ->
fmqljw4tbu = _rtP -> P_87 ; _rtB -> hpidnvqo30 = _rtP -> P_88 ; _rtB ->
japdnbcdcj = _rtP -> P_89 ; _rtB -> fqkeh503oq = _rtP -> P_90 ; _rtB ->
gvoomtptlj = _rtP -> P_91 ; _rtB -> g5djsy3mmk = _rtP -> P_96 ; _rtB ->
dajpoyb3xi = _rtP -> P_97 ; _rtB -> d0ecqku03v = _rtP -> P_108 ; _rtB ->
otzzzjlfwb = _rtP -> P_110 ; _rtB -> nvgsbb4ton = _rtP -> P_111 ; _rtB ->
opnokwubza = _rtP -> P_113 ; _rtB -> ibqizvhqon = _rtP -> P_114 ; _rtB ->
haixehcmnm = _rtP -> P_116 ; _rtB -> ik35n45sbt = _rtP -> P_117 ; _rtB ->
kpok30wx12 = _rtP -> P_119 ; _rtB -> hunlrwitx0 = _rtP -> P_120 ; _rtB ->
akbzlg0gpw = _rtP -> P_124 ; _rtB -> ahkqj2ua3f = _rtP -> P_128 ; _rtB ->
e3fa3himqr = _rtP -> P_135 ; _rtB -> paoaozuici = _rtP -> P_136 ; _rtB ->
ezowm5istg = _rtP -> P_137 ; _rtB -> o0b4ndx3oy = _rtP -> P_139 ; _rtB ->
k2dmne4mno = _rtP -> P_148 ; _rtB -> klsljezotp = _rtP -> P_158 ; _rtB ->
cuhjqm1ucp = _rtP -> P_168 ; _rtB -> oblffigztc = _rtP -> P_171 ; _rtB ->
mn2oa4zbvl = _rtP -> P_179 ; _rtB -> ccfvhczdkk = _rtP -> P_181 ; _rtB ->
puinrhb2qm = _rtP -> P_183 ; if ( _rtP -> P_184 > _rtP -> P_185 ) { _rtB ->
mefeco3esd = _rtP -> P_185 ; } else if ( _rtP -> P_184 < _rtP -> P_186 ) {
_rtB -> mefeco3esd = _rtP -> P_186 ; } else { _rtB -> mefeco3esd = _rtP ->
P_184 ; } UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdate ( SimStruct * S , int_T tid ) { d0zkhgwawu * _rtB ;
inli0fq1nl * _rtP ; lbhaipo2el * _rtX ; a502cmnw43 * _rtDW ; _rtDW = ( (
a502cmnw43 * ) ssGetRootDWork ( S ) ) ; _rtX = ( ( lbhaipo2el * )
ssGetContStates ( S ) ) ; _rtP = ( ( inli0fq1nl * ) ssGetDefaultParam ( S ) )
; _rtB = ( ( d0zkhgwawu * ) _ssGetBlockIO ( S ) ) ; if ( _rtX -> co5ubxh3w3
== _rtP -> P_28 ) { switch ( _rtDW -> hdctxpu4qo ) { case 3 : if ( _rtB ->
lni02wtqx0 < 0.0 ) { ssSetSolverNeedsReset ( S ) ; _rtDW -> hdctxpu4qo = 1 ;
} break ; case 1 : if ( _rtB -> lni02wtqx0 >= 0.0 ) { _rtDW -> hdctxpu4qo = 3
; ssSetSolverNeedsReset ( S ) ; } break ; default : ssSetSolverNeedsReset ( S
) ; if ( _rtB -> lni02wtqx0 < 0.0 ) { _rtDW -> hdctxpu4qo = 1 ; } else {
_rtDW -> hdctxpu4qo = 3 ; } break ; } } else if ( _rtX -> co5ubxh3w3 == _rtP
-> P_29 ) { switch ( _rtDW -> hdctxpu4qo ) { case 4 : if ( _rtB -> lni02wtqx0
> 0.0 ) { ssSetSolverNeedsReset ( S ) ; _rtDW -> hdctxpu4qo = 2 ; } break ;
case 2 : if ( _rtB -> lni02wtqx0 <= 0.0 ) { _rtDW -> hdctxpu4qo = 4 ;
ssSetSolverNeedsReset ( S ) ; } break ; default : ssSetSolverNeedsReset ( S )
; if ( _rtB -> lni02wtqx0 > 0.0 ) { _rtDW -> hdctxpu4qo = 2 ; } else { _rtDW
-> hdctxpu4qo = 4 ; } break ; } } else { _rtDW -> hdctxpu4qo = 0 ; } _rtDW ->
p54ywcoivr = 0 ; if ( _rtX -> mbi5wbgodl == _rtP -> P_38 ) { switch ( _rtDW
-> gu2okzutl4 ) { case 3 : if ( _rtB -> opnokwubza < 0.0 ) {
ssSetSolverNeedsReset ( S ) ; _rtDW -> gu2okzutl4 = 1 ; } break ; case 1 : if
( _rtB -> opnokwubza >= 0.0 ) { _rtDW -> gu2okzutl4 = 3 ;
ssSetSolverNeedsReset ( S ) ; } break ; default : ssSetSolverNeedsReset ( S )
; if ( _rtB -> opnokwubza < 0.0 ) { _rtDW -> gu2okzutl4 = 1 ; } else { _rtDW
-> gu2okzutl4 = 3 ; } break ; } } else if ( _rtX -> mbi5wbgodl == _rtP ->
P_39 ) { switch ( _rtDW -> gu2okzutl4 ) { case 4 : if ( _rtB -> opnokwubza >
0.0 ) { ssSetSolverNeedsReset ( S ) ; _rtDW -> gu2okzutl4 = 2 ; } break ;
case 2 : if ( _rtB -> opnokwubza <= 0.0 ) { _rtDW -> gu2okzutl4 = 4 ;
ssSetSolverNeedsReset ( S ) ; } break ; default : ssSetSolverNeedsReset ( S )
; if ( _rtB -> opnokwubza > 0.0 ) { _rtDW -> gu2okzutl4 = 2 ; } else { _rtDW
-> gu2okzutl4 = 4 ; } break ; } } else { _rtDW -> gu2okzutl4 = 0 ; } if (
_rtX -> lgagow5yei == _rtP -> P_46 ) { switch ( _rtDW -> i1p2l3jqrx ) { case
3 : if ( _rtB -> nrtdj4obb2 < 0.0 ) { ssSetSolverNeedsReset ( S ) ; _rtDW ->
i1p2l3jqrx = 1 ; } break ; case 1 : if ( _rtB -> nrtdj4obb2 >= 0.0 ) { _rtDW
-> i1p2l3jqrx = 3 ; ssSetSolverNeedsReset ( S ) ; } break ; default :
ssSetSolverNeedsReset ( S ) ; if ( _rtB -> nrtdj4obb2 < 0.0 ) { _rtDW ->
i1p2l3jqrx = 1 ; } else { _rtDW -> i1p2l3jqrx = 3 ; } break ; } } else if (
_rtX -> lgagow5yei == _rtP -> P_47 ) { switch ( _rtDW -> i1p2l3jqrx ) { case
4 : if ( _rtB -> nrtdj4obb2 > 0.0 ) { ssSetSolverNeedsReset ( S ) ; _rtDW ->
i1p2l3jqrx = 2 ; } break ; case 2 : if ( _rtB -> nrtdj4obb2 <= 0.0 ) { _rtDW
-> i1p2l3jqrx = 4 ; ssSetSolverNeedsReset ( S ) ; } break ; default :
ssSetSolverNeedsReset ( S ) ; if ( _rtB -> nrtdj4obb2 > 0.0 ) { _rtDW ->
i1p2l3jqrx = 2 ; } else { _rtDW -> i1p2l3jqrx = 4 ; } break ; } } else {
_rtDW -> i1p2l3jqrx = 0 ; } _rtDW -> cw4vcfdnns = 0 ; if ( _rtX -> ot1icumkg5
== _rtP -> P_62 ) { switch ( _rtDW -> iyv13w5nl3 ) { case 3 : if ( _rtB ->
kpok30wx12 < 0.0 ) { ssSetSolverNeedsReset ( S ) ; _rtDW -> iyv13w5nl3 = 1 ;
} break ; case 1 : if ( _rtB -> kpok30wx12 >= 0.0 ) { _rtDW -> iyv13w5nl3 = 3
; ssSetSolverNeedsReset ( S ) ; } break ; default : ssSetSolverNeedsReset ( S
) ; if ( _rtB -> kpok30wx12 < 0.0 ) { _rtDW -> iyv13w5nl3 = 1 ; } else {
_rtDW -> iyv13w5nl3 = 3 ; } break ; } } else if ( _rtX -> ot1icumkg5 == _rtP
-> P_63 ) { switch ( _rtDW -> iyv13w5nl3 ) { case 4 : if ( _rtB -> kpok30wx12
> 0.0 ) { ssSetSolverNeedsReset ( S ) ; _rtDW -> iyv13w5nl3 = 2 ; } break ;
case 2 : if ( _rtB -> kpok30wx12 <= 0.0 ) { _rtDW -> iyv13w5nl3 = 4 ;
ssSetSolverNeedsReset ( S ) ; } break ; default : ssSetSolverNeedsReset ( S )
; if ( _rtB -> kpok30wx12 > 0.0 ) { _rtDW -> iyv13w5nl3 = 2 ; } else { _rtDW
-> iyv13w5nl3 = 4 ; } break ; } } else { _rtDW -> iyv13w5nl3 = 0 ; }
ssCallAccelRunBlock ( S , 12 , 78 , SS_CALL_MDL_UPDATE ) ; if ( ssIsSampleHit
( S , 1 , 0 ) ) { _rtDW -> pekgcqftt5 = _rtB -> piazyy52ly ; }
UNUSED_PARAMETER ( tid ) ; }
#define MDL_UPDATE
static void mdlUpdateTID3 ( SimStruct * S , int_T tid ) { UNUSED_PARAMETER (
tid ) ; }
#define MDL_DERIVATIVES
static void mdlDerivatives ( SimStruct * S ) { d0zkhgwawu * _rtB ; inli0fq1nl
* _rtP ; ou3tya32xz * _rtXdis ; kj3wwgexvz * _rtXdot ; a502cmnw43 * _rtDW ;
_rtDW = ( ( a502cmnw43 * ) ssGetRootDWork ( S ) ) ; _rtXdot = ( ( kj3wwgexvz
* ) ssGetdX ( S ) ) ; _rtXdis = ( ( ou3tya32xz * ) ssGetContStateDisabled ( S
) ) ; _rtP = ( ( inli0fq1nl * ) ssGetDefaultParam ( S ) ) ; _rtB = ( (
d0zkhgwawu * ) _ssGetBlockIO ( S ) ) ; if ( ( _rtDW -> hdctxpu4qo != 3 ) && (
_rtDW -> hdctxpu4qo != 4 ) ) { _rtXdot -> co5ubxh3w3 = _rtB -> lni02wtqx0 ;
_rtXdis -> co5ubxh3w3 = false ; } else { _rtXdot -> co5ubxh3w3 = 0.0 ; if ( (
_rtDW -> hdctxpu4qo == 3 ) || ( _rtDW -> hdctxpu4qo == 4 ) ) { _rtXdis ->
co5ubxh3w3 = true ; } } _rtXdot -> ma3glufdgs = _rtB -> p1ie0qb2py ; if ( (
_rtDW -> gu2okzutl4 != 3 ) && ( _rtDW -> gu2okzutl4 != 4 ) ) { _rtXdot ->
mbi5wbgodl = _rtB -> opnokwubza ; _rtXdis -> mbi5wbgodl = false ; } else {
_rtXdot -> mbi5wbgodl = 0.0 ; if ( ( _rtDW -> gu2okzutl4 == 3 ) || ( _rtDW ->
gu2okzutl4 == 4 ) ) { _rtXdis -> mbi5wbgodl = true ; } } if ( ( _rtDW ->
i1p2l3jqrx != 3 ) && ( _rtDW -> i1p2l3jqrx != 4 ) ) { _rtXdot -> lgagow5yei =
_rtB -> nrtdj4obb2 ; _rtXdis -> lgagow5yei = false ; } else { _rtXdot ->
lgagow5yei = 0.0 ; if ( ( _rtDW -> i1p2l3jqrx == 3 ) || ( _rtDW -> i1p2l3jqrx
== 4 ) ) { _rtXdis -> lgagow5yei = true ; } } _rtXdot -> abcadcsyqr = _rtB ->
pvhvrsroou ; if ( ( _rtDW -> iyv13w5nl3 != 3 ) && ( _rtDW -> iyv13w5nl3 != 4
) ) { _rtXdot -> ot1icumkg5 = _rtB -> kpok30wx12 ; _rtXdis -> ot1icumkg5 =
false ; } else { _rtXdot -> ot1icumkg5 = 0.0 ; if ( ( _rtDW -> iyv13w5nl3 ==
3 ) || ( _rtDW -> iyv13w5nl3 == 4 ) ) { _rtXdis -> ot1icumkg5 = true ; } }
ssCallAccelRunBlock ( S , 12 , 73 , SS_CALL_MDL_DERIVATIVES ) ;
ssCallAccelRunBlock ( S , 12 , 78 , SS_CALL_MDL_DERIVATIVES ) ; _rtXdot ->
l4dwujw3ky = _rtB -> bloyrzaxhh ; if ( _rtDW -> mfcrnzu51s ) { _rtXdot ->
ladquobflf = _rtB -> bloyrzaxhh ; } else { ( ( kj3wwgexvz * ) ssGetdX ( S ) )
-> ladquobflf = 0.0 ; } }
#define MDL_PROJECTION
static void mdlProjection ( SimStruct * S ) { d0zkhgwawu * _rtB ; a502cmnw43
* _rtDW ; _rtDW = ( ( a502cmnw43 * ) ssGetRootDWork ( S ) ) ; _rtB = ( (
d0zkhgwawu * ) _ssGetBlockIO ( S ) ) ; ssCallAccelRunBlock ( S , 12 , 73 ,
SS_CALL_MDL_PROJECTION ) ; }
#define MDL_ZERO_CROSSINGS
static void mdlZeroCrossings ( SimStruct * S ) { boolean_T anyStateSaturated
; d0zkhgwawu * _rtB ; inli0fq1nl * _rtP ; lbhaipo2el * _rtX ; gvvcmumzez *
_rtZCSV ; a502cmnw43 * _rtDW ; _rtDW = ( ( a502cmnw43 * ) ssGetRootDWork ( S
) ) ; _rtZCSV = ( ( gvvcmumzez * ) ssGetSolverZcSignalVector ( S ) ) ; _rtX =
( ( lbhaipo2el * ) ssGetContStates ( S ) ) ; _rtP = ( ( inli0fq1nl * )
ssGetDefaultParam ( S ) ) ; _rtB = ( ( d0zkhgwawu * ) _ssGetBlockIO ( S ) ) ;
_rtZCSV -> ksxco20puv = _rtB -> oxbt0trr3a [ 0 ] - _rtB -> k3k5vqljtl ; if (
_rtDW -> lewi3ks1mz ) { _rtZCSV -> diqyisrup2 = _rtX -> ma3glufdgs - _rtP ->
P_24 ; } else { _rtZCSV -> diqyisrup2 = _rtX -> ma3glufdgs - _rtP -> P_23 ; }
if ( ( _rtDW -> hdctxpu4qo == 1 ) && ( _rtX -> co5ubxh3w3 >= _rtP -> P_28 ) )
{ _rtZCSV -> bkn3xdpryz = 0.0 ; } else { _rtZCSV -> bkn3xdpryz = _rtX ->
co5ubxh3w3 - _rtP -> P_28 ; } if ( ( _rtDW -> hdctxpu4qo == 2 ) && ( _rtX ->
co5ubxh3w3 <= _rtP -> P_29 ) ) { _rtZCSV -> modzsdfclh = 0.0 ; } else {
_rtZCSV -> modzsdfclh = _rtX -> co5ubxh3w3 - _rtP -> P_29 ; }
anyStateSaturated = false ; if ( ( _rtDW -> hdctxpu4qo == 3 ) || ( _rtDW ->
hdctxpu4qo == 4 ) ) { anyStateSaturated = true ; } if ( anyStateSaturated ) {
_rtZCSV -> ildbl3d0kv = _rtB -> lni02wtqx0 ; } else { _rtZCSV -> ildbl3d0kv =
0.0 ; } _rtZCSV -> lbv2rnzt2p = _rtB -> kobhyrri1w - _rtB -> glcoukqg5d ; if
( ( _rtDW -> gu2okzutl4 == 1 ) && ( _rtX -> mbi5wbgodl >= _rtP -> P_38 ) ) {
_rtZCSV -> cdhj3gingk = 0.0 ; } else { _rtZCSV -> cdhj3gingk = _rtX ->
mbi5wbgodl - _rtP -> P_38 ; } if ( ( _rtDW -> gu2okzutl4 == 2 ) && ( _rtX ->
mbi5wbgodl <= _rtP -> P_39 ) ) { _rtZCSV -> mygzbu33kk = 0.0 ; } else {
_rtZCSV -> mygzbu33kk = _rtX -> mbi5wbgodl - _rtP -> P_39 ; } if ( _rtDW ->
ho4raeuelg ) { _rtZCSV -> oxxrlbhrns = _rtX -> abcadcsyqr - _rtP -> P_42 ; }
else { _rtZCSV -> oxxrlbhrns = _rtX -> abcadcsyqr - _rtP -> P_41 ; } if ( (
_rtDW -> i1p2l3jqrx == 1 ) && ( _rtX -> lgagow5yei >= _rtP -> P_46 ) ) {
_rtZCSV -> a1lx12ynwi = 0.0 ; } else { _rtZCSV -> a1lx12ynwi = _rtX ->
lgagow5yei - _rtP -> P_46 ; } if ( ( _rtDW -> i1p2l3jqrx == 2 ) && ( _rtX ->
lgagow5yei <= _rtP -> P_47 ) ) { _rtZCSV -> m5wwbgkb2p = 0.0 ; } else {
_rtZCSV -> m5wwbgkb2p = _rtX -> lgagow5yei - _rtP -> P_47 ; }
anyStateSaturated = false ; if ( ( _rtDW -> i1p2l3jqrx == 3 ) || ( _rtDW ->
i1p2l3jqrx == 4 ) ) { anyStateSaturated = true ; } if ( anyStateSaturated ) {
_rtZCSV -> athjceijzu = _rtB -> nrtdj4obb2 ; } else { _rtZCSV -> athjceijzu =
0.0 ; } _rtZCSV -> cjsggumece = _rtB -> gc0ces3pny - _rtB -> ceguswtlh1 ;
_rtZCSV -> kb2zmsdr5p = _rtB -> hhze4jyfb3 - _rtB -> gqvqxivkjj ; if ( (
_rtDW -> iyv13w5nl3 == 1 ) && ( _rtX -> ot1icumkg5 >= _rtP -> P_62 ) ) {
_rtZCSV -> h3w14ynvna = 0.0 ; } else { _rtZCSV -> h3w14ynvna = _rtX ->
ot1icumkg5 - _rtP -> P_62 ; } if ( ( _rtDW -> iyv13w5nl3 == 2 ) && ( _rtX ->
ot1icumkg5 <= _rtP -> P_63 ) ) { _rtZCSV -> bilz2t53c0 = 0.0 ; } else {
_rtZCSV -> bilz2t53c0 = _rtX -> ot1icumkg5 - _rtP -> P_63 ; }
ssCallAccelRunBlock ( S , 12 , 78 , SS_CALL_MDL_ZERO_CROSSINGS ) ; _rtZCSV ->
icj2qbshzu = _rtB -> mea2ufuujr [ 3 ] - _rtB -> d0ecqku03v ; _rtZCSV ->
ntwgva0ttb = _rtB -> mea2ufuujr [ 4 ] - _rtB -> ibqizvhqon ; _rtZCSV ->
cxgwov00ge = _rtB -> jktokfxdjj [ 1 ] - _rtP -> P_121 ; _rtZCSV -> ajfeh3zcrt
= _rtB -> jfh3lr3zau - _rtP -> P_122 ; _rtZCSV -> otu5zdokm2 = _rtB ->
jfh3lr3zau - _rtP -> P_123 ; _rtZCSV -> bjm1mi3jp4 = _rtB -> jktokfxdjj [ 2 ]
- _rtP -> P_125 ; _rtZCSV -> jpchryen20 = _rtB -> nye4t3guib - _rtP -> P_126
; _rtZCSV -> gudo4id5z3 = _rtB -> nye4t3guib - _rtP -> P_127 ; _rtZCSV ->
ar5lnz10g5 = _rtB -> jktokfxdjj [ 0 ] - _rtP -> P_129 ; _rtZCSV -> c051050wjt
= _rtB -> oxbt0trr3a [ 1 ] ; if ( ! _rtDW -> mfcrnzu51s ) { } _rtZCSV ->
ohl3z5nyur = _rtB -> oxbt0trr3a [ 0 ] - _rtP -> P_141 ; _rtZCSV -> gnpxhjpx4n
= _rtB -> oxbt0trr3a [ 0 ] - _rtP -> P_142 ; _rtZCSV -> lekyjc3wto = _rtB ->
kig5rrlids - _rtP -> P_143 ; _rtZCSV -> my0jslno4s = _rtB -> kig5rrlids -
_rtP -> P_144 ; _rtZCSV -> mvfbbavaex = _rtB -> oxbt0trr3a [ 1 ] - _rtP ->
P_151 ; _rtZCSV -> a2udih5s5c = _rtB -> oxbt0trr3a [ 1 ] - _rtP -> P_152 ;
_rtZCSV -> fxfxjx0uuw = _rtB -> ojhqp2kimj - _rtP -> P_153 ; _rtZCSV ->
m5zrnplhh2 = _rtB -> ojhqp2kimj - _rtP -> P_154 ; _rtZCSV -> jb4b03tlqg =
_rtB -> oxbt0trr3a [ 1 ] - _rtP -> P_161 ; _rtZCSV -> m04p5rhszm = _rtB ->
oxbt0trr3a [ 1 ] - _rtP -> P_162 ; _rtZCSV -> cajkqnqxgr = _rtB -> c3eubtn4l4
- _rtP -> P_163 ; _rtZCSV -> iktlb01imi = _rtB -> c3eubtn4l4 - _rtP -> P_164
; _rtZCSV -> mdovb1r01h = _rtB -> n25aj5zh1t - _rtP -> P_172 ; _rtZCSV ->
a10viq3155 = _rtB -> n25aj5zh1t - _rtP -> P_173 ; _rtZCSV -> i4cdvuics2 =
_rtB -> g2lzaghajm - _rtP -> P_174 ; _rtZCSV -> ocytsj0m0d = _rtB ->
g2lzaghajm - _rtP -> P_175 ; ssCallAccelRunBlock ( S , 12 , 292 ,
SS_CALL_MDL_ZERO_CROSSINGS ) ; } static void mdlInitializeSizes ( SimStruct *
S ) { ssSetChecksumVal ( S , 0 , 1376295405U ) ; ssSetChecksumVal ( S , 1 ,
2857952970U ) ; ssSetChecksumVal ( S , 2 , 3124670847U ) ; ssSetChecksumVal (
S , 3 , 1178427719U ) ; { mxArray * slVerStructMat = NULL ; mxArray *
slStrMat = mxCreateString ( "simulink" ) ; char slVerChar [ 10 ] ; int status
= mexCallMATLAB ( 1 , & slVerStructMat , 1 , & slStrMat , "ver" ) ; if (
status == 0 ) { mxArray * slVerMat = mxGetField ( slVerStructMat , 0 ,
"Version" ) ; if ( slVerMat == NULL ) { status = 1 ; } else { status =
mxGetString ( slVerMat , slVerChar , 10 ) ; } } mxDestroyArray ( slStrMat ) ;
mxDestroyArray ( slVerStructMat ) ; if ( ( status == 1 ) || ( strcmp (
slVerChar , "8.6" ) != 0 ) ) { return ; } } ssSetOptions ( S ,
SS_OPTION_EXCEPTION_FREE_CODE ) ; if ( ssGetSizeofDWork ( S ) != sizeof (
a502cmnw43 ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal DWork sizes do "
"not match for accelerator mex file." ) ; } if ( ssGetSizeofGlobalBlockIO ( S
) != sizeof ( d0zkhgwawu ) ) { ssSetErrorStatus ( S ,
"Unexpected error: Internal BlockIO sizes do "
"not match for accelerator mex file." ) ; } { int ssSizeofParams ;
ssGetSizeofParams ( S , & ssSizeofParams ) ; if ( ssSizeofParams != sizeof (
inli0fq1nl ) ) { static char msg [ 256 ] ; sprintf ( msg ,
"Unexpected error: Internal Parameters sizes do "
"not match for accelerator mex file." ) ; } } _ssSetDefaultParam ( S , (
real_T * ) & cbzlpw5poz ) ; rt_InitInfAndNaN ( sizeof ( real_T ) ) ; ( (
inli0fq1nl * ) ssGetDefaultParam ( S ) ) -> P_29 = rtMinusInf ; ( (
inli0fq1nl * ) ssGetDefaultParam ( S ) ) -> P_38 = rtInf ; ( ( inli0fq1nl * )
ssGetDefaultParam ( S ) ) -> P_39 = rtMinusInf ; ( ( inli0fq1nl * )
ssGetDefaultParam ( S ) ) -> P_47 = rtMinusInf ; ( ( inli0fq1nl * )
ssGetDefaultParam ( S ) ) -> P_62 = rtInf ; ( ( inli0fq1nl * )
ssGetDefaultParam ( S ) ) -> P_63 = rtMinusInf ; ( ( inli0fq1nl * )
ssGetDefaultParam ( S ) ) -> P_73 = rtNaN ; ( ( inli0fq1nl * )
ssGetDefaultParam ( S ) ) -> P_75 = rtNaN ; ( ( inli0fq1nl * )
ssGetDefaultParam ( S ) ) -> P_78 = rtNaN ; ( ( inli0fq1nl * )
ssGetDefaultParam ( S ) ) -> P_85 = rtNaN ; ( ( inli0fq1nl * )
ssGetDefaultParam ( S ) ) -> P_88 = rtNaN ; ( ( inli0fq1nl * )
ssGetDefaultParam ( S ) ) -> P_90 = rtNaN ; ( ( inli0fq1nl * )
ssGetDefaultParam ( S ) ) -> P_122 = rtInf ; ( ( inli0fq1nl * )
ssGetDefaultParam ( S ) ) -> P_126 = rtInf ; ( ( inli0fq1nl * )
ssGetDefaultParam ( S ) ) -> P_141 = rtInf ; ( ( inli0fq1nl * )
ssGetDefaultParam ( S ) ) -> P_151 = rtInf ; ( ( inli0fq1nl * )
ssGetDefaultParam ( S ) ) -> P_161 = rtInf ; ( ( inli0fq1nl * )
ssGetDefaultParam ( S ) ) -> P_172 = rtInf ; } static void
mdlInitializeSampleTimes ( SimStruct * S ) { slAccRegPrmChangeFcn ( S ,
mdlOutputsTID3 ) ; } static void mdlTerminate ( SimStruct * S ) { }
#include "simulink.c"
