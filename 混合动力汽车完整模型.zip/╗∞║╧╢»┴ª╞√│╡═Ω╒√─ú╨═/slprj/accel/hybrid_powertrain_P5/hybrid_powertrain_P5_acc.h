#include "__cf_hybrid_powertrain_P5.h"
#ifndef RTW_HEADER_hybrid_powertrain_P5_acc_h_
#define RTW_HEADER_hybrid_powertrain_P5_acc_h_
#include <float.h>
#include <stddef.h>
#ifndef hybrid_powertrain_P5_acc_COMMON_INCLUDES_
#define hybrid_powertrain_P5_acc_COMMON_INCLUDES_
#include <stdlib.h>
#define S_FUNCTION_NAME simulink_only_sfcn 
#define S_FUNCTION_LEVEL 2
#define RTW_GENERATED_S_FUNCTION
#include "rtwtypes.h"
#include "simstruc.h"
#include "fixedpoint.h"
#endif
#include "hybrid_powertrain_P5_acc_types.h"
#include "multiword_types.h"
#include "mwmathutil.h"
#include "rt_zcfcn.h"
#include "rtGetInf.h"
#include "rt_nonfinite.h"
#include "rt_look.h"
#include "rt_look1d.h"
#include "rtGetNaN.h"
#include "rt_defines.h"
typedef struct { real_T oxbt0trr3a [ 3 ] ; real_T k3k5vqljtl ; real_T
p3its42cvd ; real_T lpcl44nchu [ 3 ] ; real_T kobhyrri1w ; real_T glcoukqg5d
; real_T nyykdh4onm ; real_T bhfrfh0x2b ; real_T n3zdq0wmp3 ; real_T
dgn1zot3ia ; real_T ixbocf0kdl ; real_T b1qykfn1xt ; real_T gc0ces3pny ;
real_T ceguswtlh1 ; real_T gor00zeg0p ; real_T hhze4jyfb3 ; real_T gqvqxivkjj
; real_T jxqolpe13z ; real_T gwc5uhen0e ; real_T bq2p0tfbqz ; real_T
oadpnkwogk ; real_T kvcaqm5tmx ; real_T mjqgyevsmb ; real_T imbmaebgbs ;
real_T ncl5zyxx31 ; real_T gpbdctsrm1 ; real_T ke031wwb25 ; real_T fjd5vjfs2b
; real_T c45tydnt5f ; real_T f5oj515tvf ; real_T gtc30z5nru ; real_T
l02aoh4vmx ; real_T dahuht42nw ; real_T cwixgqpm0a ; real_T b4i4wrrkuo ;
real_T i3eowuclfr ; real_T eaofgv2qh2 ; real_T kcrerj13yf ; real_T eyugbm4xom
; real_T leso1ekrxv ; real_T ghgmuyxgtc ; real_T h51nzyvoy4 ; real_T
mrhwsddjxw ; real_T c1lav4hnkn ; real_T dczisasage ; real_T mxxzbgpi4s ;
real_T fmqljw4tbu ; real_T hpidnvqo30 ; real_T japdnbcdcj ; real_T fqkeh503oq
; real_T mdbif4xnjc [ 25 ] ; real_T gvoomtptlj ; real_T cffpsw0rzm ; real_T
eb2aix04zk ; real_T ldteezdf3g ; real_T henas0kods ; real_T onaxsft1kx ;
real_T n0cgwmyxxg [ 4 ] ; real_T hkw0s41a4o ; real_T avpfijxdss [ 14 ] ;
real_T a25naqbzdy ; real_T ndb5ndewd4 ; real_T g5djsy3mmk ; real_T dajpoyb3xi
; real_T mea2ufuujr [ 7 ] ; real_T jktokfxdjj [ 3 ] ; real_T d0ecqku03v ;
real_T i0mziyc3ux ; real_T g4cnccoqkb ; real_T lni02wtqx0 ; real_T otzzzjlfwb
; real_T nvgsbb4ton ; real_T p1ie0qb2py ; real_T opnokwubza ; real_T
ibqizvhqon ; real_T phkow4yd4b ; real_T mlpegorz1k ; real_T nrtdj4obb2 ;
real_T haixehcmnm ; real_T ik35n45sbt ; real_T pvhvrsroou ; real_T kpok30wx12
; real_T hunlrwitx0 ; real_T jfh3lr3zau ; real_T akbzlg0gpw ; real_T
nye4t3guib ; real_T ahkqj2ua3f ; real_T mlnkiltx2b ; real_T pair4ggt4i ;
real_T bloyrzaxhh ; real_T jlubof3i50 ; real_T e3fa3himqr ; real_T paoaozuici
; real_T ezowm5istg ; real_T bg3kaqmiys ; real_T piazyy52ly ; real_T
o0b4ndx3oy ; real_T c3o41hirka ; real_T cdh0xotdk1 ; real_T kig5rrlids ;
real_T jl010lq1f3 ; real_T ny1uobvgb3 ; real_T ak3thacfgs ; real_T k2dmne4mno
; real_T mi2o5chvxm ; real_T i4drpk5ht4 ; real_T fr2hbsmfao ; real_T
bc2o1mbeld ; real_T phrvdyxuzp ; real_T ojhqp2kimj ; real_T ijxdhs0j2l ;
real_T keu2i33rym ; real_T cz0ift2ina ; real_T klsljezotp ; real_T b4ckgilcpm
; real_T l35q5ah34p ; real_T losjyzzb5e ; real_T nv3juwiv0q ; real_T
e01kesqul1 ; real_T c3eubtn4l4 ; real_T ealuglnzhy ; real_T orcxjpabjz ;
real_T iwgu3iv0kp ; real_T cuhjqm1ucp ; real_T k1bo2xs3um ; real_T eiz5zfcews
; real_T acet1mfjkq ; real_T psdyfvtwdy ; real_T luw15ec4bt ; real_T
oblffigztc ; real_T n25aj5zh1t ; real_T g2lzaghajm ; real_T my4o1wzxls ;
real_T ofe3bdzsnu ; real_T iyg21km0vp ; real_T mn2oa4zbvl ; real_T augpda41rt
; real_T cka4c1uz32 ; real_T fvksuvd2bm ; real_T ccfvhczdkk ; real_T
op4o3vof2h ; real_T puinrhb2qm ; real_T mefeco3esd ; real_T jsk4ciqudh ;
real_T bvfpzmhsjj [ 14 ] ; real_T oopqztyn3o ; real_T hz3fc1r51u [ 6 ] ;
real_T ednzse43oa ; real_T eyfbm4c2t4 ; real_T ovkvs3sana ; real_T jsgafk5xp5
; real_T nd5j1bcc4h ; real_T miee1ahi03 ; real_T awyww2rqvx ; real_T
fd5h3psjmp ; real_T fnelsjy5g5 ; real_T jasmb5tzyk ; real_T jf5khtnu3w ;
real_T drcatqd2yf ; real_T c1y005tndo ; real_T jdghtvuipb ; real_T omk0qn4hpv
; real_T i43alvyekm ; real_T ioivuu43kl ; real_T cyxsvrsorb ; real_T
l4zzfprpaf ; boolean_T djdy32us3n ; char pad_djdy32us3n [ 7 ] ; } d0zkhgwawu
; typedef struct { real_T pekgcqftt5 ; real_T hmenkbqdul ; real_T dmlgpabp13
; int64_T eqdmsmu11f ; real_T pcqilc0snk ; void * jvaott02py [ 3 ] ; void *
mcjzaf0b3n ; void * mmlzhoolsa ; struct { void * AS ; void * BS ; void * CS ;
void * DS ; void * DX_COL ; void * BD_COL ; void * TMP1 ; void * TMP2 ; void
* SWITCH_STATUS ; void * SWITCH_STATUS_INIT ; void * SW_CHG ; void * G_STATE
; void * USWLAST ; void * IDX_SW_CHG ; void * Y_SWITCH ; void * SWITCH_TYPES
; void * IDX_OUT_SW ; void * SWITCH_TOPO_SAVED_IDX ; void * SWITCH_MAP ; }
fcvbl3zdhh ; void * cljlkiocfn [ 3 ] ; void * cts3dftoso ; void * fhkittftrq
; void * j5oiefji4e ; void * orvdc0oxkr ; int32_T ewvzwysh0q ; int32_T
isnimkczge ; int_T pvx1kmzml3 ; int_T p54ywcoivr ; int_T cw4vcfdnns ; int_T
kzilre34yw ; int_T drnzk1aed0 ; int_T btnbueekne ; int_T bwxupjzrgx [ 9 ] ;
int_T phvmgpd05z ; int_T hx5c3kzj0i ; int_T hdctxpu4qo ; int_T gu2okzutl4 ;
int_T i1p2l3jqrx ; int_T iyv13w5nl3 ; char akvdkkzjy5 [ 4 ] ; int_T
o3dtsgph5d ; int_T ok0xhshmnd ; int_T dhiac513xj ; int_T kmdcusof2v ; int_T
povnrj5nez ; int_T ppkb5f3njb ; int_T pv3jjmmhsg ; int_T ic45asbzur ; int_T
br3b5dudjv ; int_T iqny0hs2z4 ; char pzstt223th [ 16 ] ; int8_T gop25k0t2l ;
boolean_T nvnkw0twvc ; boolean_T lewi3ks1mz ; boolean_T dwg20kttxu ;
boolean_T ljeuuxjryc ; boolean_T pobimgru15 ; boolean_T ho4raeuelg ;
boolean_T mninf3v1di ; boolean_T ovaeihxq1z ; boolean_T cpr52i3ku4 ;
boolean_T hmvptpy4fe ; boolean_T hvk2q5h42l ; boolean_T dvhorkzgao ;
boolean_T fdeeygjlko ; boolean_T owecgug4s2 ; boolean_T o1iltqmmdo ;
boolean_T mfcrnzu51s ; char pad_mfcrnzu51s [ 7 ] ; } a502cmnw43 ; typedef
struct { real_T co5ubxh3w3 ; real_T ma3glufdgs ; real_T mbi5wbgodl ; real_T
lgagow5yei ; real_T abcadcsyqr ; real_T ot1icumkg5 ; real_T nuyji2lmei [ 4 ]
; real_T dxy1kaj2am ; real_T l4dwujw3ky ; real_T ladquobflf ; } lbhaipo2el ;
typedef struct { real_T co5ubxh3w3 ; real_T ma3glufdgs ; real_T mbi5wbgodl ;
real_T lgagow5yei ; real_T abcadcsyqr ; real_T ot1icumkg5 ; real_T nuyji2lmei
[ 4 ] ; real_T dxy1kaj2am ; real_T l4dwujw3ky ; real_T ladquobflf ; }
kj3wwgexvz ; typedef struct { boolean_T co5ubxh3w3 ; boolean_T ma3glufdgs ;
boolean_T mbi5wbgodl ; boolean_T lgagow5yei ; boolean_T abcadcsyqr ;
boolean_T ot1icumkg5 ; boolean_T nuyji2lmei [ 4 ] ; boolean_T dxy1kaj2am ;
boolean_T l4dwujw3ky ; boolean_T ladquobflf ; } ou3tya32xz ; typedef struct {
real_T co5ubxh3w3 ; real_T ma3glufdgs ; real_T mbi5wbgodl ; real_T lgagow5yei
; real_T abcadcsyqr ; real_T ot1icumkg5 ; real_T nuyji2lmei [ 4 ] ; real_T
dxy1kaj2am ; real_T l4dwujw3ky ; real_T ladquobflf ; } e5152lkpj1 ; typedef
struct { real_T ksxco20puv ; real_T diqyisrup2 ; real_T bkn3xdpryz ; real_T
modzsdfclh ; real_T ildbl3d0kv ; real_T lbv2rnzt2p ; real_T fdryvvbykq ;
real_T jsuexj0d1c ; real_T cdhj3gingk ; real_T mygzbu33kk ; real_T oxxrlbhrns
; real_T a1lx12ynwi ; real_T m5wwbgkb2p ; real_T athjceijzu ; real_T
cjsggumece ; real_T kb2zmsdr5p ; real_T fxzudbo5ai ; real_T ki4ydqb4by ;
real_T h3w14ynvna ; real_T bilz2t53c0 ; real_T fke2c2z1wv [ 4 ] ; real_T
icj2qbshzu ; real_T ntwgva0ttb ; real_T cxgwov00ge ; real_T ajfeh3zcrt ;
real_T otu5zdokm2 ; real_T bjm1mi3jp4 ; real_T jpchryen20 ; real_T gudo4id5z3
; real_T ar5lnz10g5 ; real_T ohl3z5nyur ; real_T gnpxhjpx4n ; real_T
lekyjc3wto ; real_T my0jslno4s ; real_T mvfbbavaex ; real_T a2udih5s5c ;
real_T fxfxjx0uuw ; real_T m5zrnplhh2 ; real_T jb4b03tlqg ; real_T m04p5rhszm
; real_T cajkqnqxgr ; real_T iktlb01imi ; real_T mdovb1r01h ; real_T
a10viq3155 ; real_T i4cdvuics2 ; real_T ocytsj0m0d ; real_T oqxhut4yxp [ 16 ]
; real_T c051050wjt ; } gvvcmumzez ; typedef struct { ZCSigState i2flwiaeqc ;
ZCSigState ldpsi5loli ; ZCSigState j0dzsckucn ; ZCSigState ptezqlaqkc ;
ZCSigState mztnueonje ; ZCSigState db0bszmoae ; ZCSigState jo0e41jv05 ;
ZCSigState fepub5kpxh ; ZCSigState k04le5yijy ; ZCSigState nnk5ei0m5u ;
ZCSigState iufyrblf1f ; ZCSigState p3chgzco0x ; ZCSigState cvv2c1k2ft ;
ZCSigState p4zyp24vs0 ; ZCSigState g2kf0b1am4 ; ZCSigState ebatufogg5 ;
ZCSigState fklxzrbqc1 ; ZCSigState bhwoijscij ; ZCSigState bxhp3gv3rn ;
ZCSigState md4tgr0jte ; ZCSigState lyjqazqn2p [ 4 ] ; ZCSigState c2woez2ubc ;
ZCSigState ksvndfosuk ; ZCSigState cav1trblbc ; ZCSigState iy43lwvhdr ;
ZCSigState fraskwzybf ; ZCSigState lsdu1k534f ; ZCSigState oilvtp2crj ;
ZCSigState lymxeoslb4 ; ZCSigState jqogi2tlka ; ZCSigState e3twap541u ;
ZCSigState k300qmzfhk ; ZCSigState muxzfeyp1y ; ZCSigState dpfhpnxbzc ;
ZCSigState fo3k3w4wko ; ZCSigState alklfr3ilo ; ZCSigState mxndzxewpw ;
ZCSigState ogizjaarf2 ; ZCSigState pzitblusvw ; ZCSigState l5ta34m3at ;
ZCSigState fxb43eeqvf ; ZCSigState gmmv2xzmnm ; ZCSigState id41kkkpmk ;
ZCSigState f5cadzepzn ; ZCSigState hhwvtripwd ; ZCSigState j3pcbpxnpk ;
ZCSigState km2vo0knu5 [ 16 ] ; ZCSigState pi4jwsizta ; } jdannnw0pz ; struct
inli0fq1nl_ { real_T P_0 ; real_T P_1 ; real_T P_2 ; real_T P_3 ; real_T P_4
; real_T P_5 ; real_T P_6 [ 4 ] ; real_T P_7 [ 4 ] ; real_T P_8 ; real_T P_9
; real_T P_10 [ 4 ] ; real_T P_11 [ 4 ] ; real_T P_12 ; real_T P_13 ; real_T
P_14 [ 101 ] ; real_T P_15 [ 101 ] ; real_T P_16 ; real_T P_17 ; real_T P_18
; real_T P_19 ; real_T P_20 ; real_T P_21 ; real_T P_22 [ 3 ] ; real_T P_23 ;
real_T P_24 ; real_T P_25 ; real_T P_26 ; real_T P_27 ; real_T P_28 ; real_T
P_29 ; real_T P_30 ; real_T P_31 ; real_T P_32 ; real_T P_33 ; real_T P_34 ;
real_T P_35 ; real_T P_36 ; real_T P_37 ; real_T P_38 ; real_T P_39 ; real_T
P_40 ; real_T P_41 ; real_T P_42 ; real_T P_43 ; real_T P_44 ; real_T P_45 ;
real_T P_46 ; real_T P_47 ; real_T P_48 ; real_T P_49 ; real_T P_50 ; real_T
P_51 ; real_T P_52 ; real_T P_53 ; real_T P_54 ; real_T P_55 ; real_T P_56 ;
real_T P_57 ; real_T P_58 ; real_T P_59 ; real_T P_60 ; real_T P_61 ; real_T
P_62 ; real_T P_63 ; real_T P_64 ; real_T P_65 ; real_T P_66 ; real_T P_67 ;
real_T P_68 ; real_T P_69 ; real_T P_70 ; real_T P_71 ; real_T P_72 ; real_T
P_73 ; real_T P_74 ; real_T P_75 ; real_T P_76 ; real_T P_77 ; real_T P_78 ;
real_T P_79 ; real_T P_80 ; real_T P_81 ; real_T P_82 ; real_T P_83 ; real_T
P_84 ; real_T P_85 ; real_T P_86 ; real_T P_87 ; real_T P_88 ; real_T P_89 ;
real_T P_90 ; real_T P_91 ; real_T P_92 ; real_T P_93 ; real_T P_94 ; real_T
P_95 ; real_T P_96 ; real_T P_97 ; real_T P_98 [ 2 ] ; real_T P_99 ; real_T
P_100 [ 2 ] ; real_T P_101 [ 9 ] ; real_T P_102 [ 2 ] ; real_T P_103 [ 7 ] ;
real_T P_104 [ 2 ] ; real_T P_105 [ 63 ] ; real_T P_106 [ 2 ] ; real_T P_107
; real_T P_108 ; real_T P_109 ; real_T P_110 ; real_T P_111 ; real_T P_112 ;
real_T P_113 ; real_T P_114 ; real_T P_115 ; real_T P_116 ; real_T P_117 ;
real_T P_118 ; real_T P_119 ; real_T P_120 ; real_T P_121 ; real_T P_122 ;
real_T P_123 ; real_T P_124 ; real_T P_125 ; real_T P_126 ; real_T P_127 ;
real_T P_128 ; real_T P_129 ; real_T P_130 ; real_T P_131 ; real_T P_132 ;
real_T P_133 ; real_T P_134 ; real_T P_135 ; real_T P_136 ; real_T P_137 ;
real_T P_138 ; real_T P_139 ; real_T P_140 ; real_T P_141 ; real_T P_142 ;
real_T P_143 ; real_T P_144 ; real_T P_145 ; real_T P_146 [ 2 ] ; real_T
P_147 [ 2 ] ; real_T P_148 ; real_T P_149 ; real_T P_150 ; real_T P_151 ;
real_T P_152 ; real_T P_153 ; real_T P_154 ; real_T P_155 ; real_T P_156 [ 2
] ; real_T P_157 [ 2 ] ; real_T P_158 ; real_T P_159 ; real_T P_160 ; real_T
P_161 ; real_T P_162 ; real_T P_163 ; real_T P_164 ; real_T P_165 ; real_T
P_166 [ 2 ] ; real_T P_167 [ 2 ] ; real_T P_168 ; real_T P_169 ; real_T P_170
; real_T P_171 ; real_T P_172 ; real_T P_173 ; real_T P_174 ; real_T P_175 ;
real_T P_176 ; real_T P_177 [ 2 ] ; real_T P_178 [ 2 ] ; real_T P_179 ;
real_T P_180 ; real_T P_181 ; real_T P_182 ; real_T P_183 ; real_T P_184 ;
real_T P_185 ; real_T P_186 ; real_T P_187 ; real_T P_188 ; real_T P_189 ;
uint8_T P_190 ; char pad_P_190 [ 7 ] ; } ; extern inli0fq1nl cbzlpw5poz ;
#endif
