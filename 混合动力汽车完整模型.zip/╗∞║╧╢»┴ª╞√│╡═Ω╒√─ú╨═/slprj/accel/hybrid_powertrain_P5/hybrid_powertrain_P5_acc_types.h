#include "__cf_hybrid_powertrain_P5.h"
#ifndef RTW_HEADER_hybrid_powertrain_P5_acc_types_h_
#define RTW_HEADER_hybrid_powertrain_P5_acc_types_h_
#include "rtwtypes.h"
#include "multiword_types.h"
#ifndef SS_INT64
#define SS_INT64  15
#endif
#ifndef SS_UINT64
#define SS_UINT64  16
#endif
typedef struct inli0fq1nl_ inli0fq1nl ;
#endif
