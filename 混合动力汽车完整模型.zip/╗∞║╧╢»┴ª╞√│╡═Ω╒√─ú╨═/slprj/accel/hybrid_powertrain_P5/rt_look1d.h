#include "__cf_hybrid_powertrain_P5.h"
#ifndef RTW_HEADER_rt_look1d_h_
#define RTW_HEADER_rt_look1d_h_
#include "rtwtypes.h"
#include "rt_look.h"
extern real_T rt_Lookup ( const real_T * x , int_T xlen , real_T u , const
real_T * y ) ;
#endif
